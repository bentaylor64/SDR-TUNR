#!/usr/bin/env python3
"""Partition native directory snapshots into deterministic, lazy browser tiles.

No network access or third-party dependencies. Original records and source
metadata remain unchanged; the manifest also stores each source file's hash.
"""

import argparse
import hashlib
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TILE_DEGREES = 2


def json_bytes(value):
    return (json.dumps(value, separators=(",", ":"), ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")


def build_payloads():
    manifest = {"version": 1, "tileDegrees": TILE_DEGREES, "catalogs": [], "tiles": []}
    payloads = {}
    identifiers = set()
    for name in ("airports", "repeaters"):
        source = ROOT / "Sources" / "Tuner" / "Resources" / f"{name}.json"
        raw = source.read_bytes()
        catalog = json.loads(raw)
        stations = catalog["stations"]
        metadata = {key: value for key, value in catalog.items() if key != "stations"}
        metadata.update(id=name, stationCount=len(stations), sourceSHA256=hashlib.sha256(raw).hexdigest())
        manifest["catalogs"].append(metadata)
        tiles = {}
        for station in stations:
            identifier = station["id"]
            if not isinstance(identifier, str) or not identifier or identifier in identifiers:
                raise ValueError(f"Missing or duplicate station identifier in {name}")
            identifiers.add(identifier)
            latitude, longitude = station["latitude"], station["longitude"]
            if not (math.isfinite(latitude) and math.isfinite(longitude) and -90 <= latitude <= 90 and -180 <= longitude <= 180):
                raise ValueError(f"Invalid coordinates for {identifier}")
            south = math.floor(latitude / TILE_DEGREES) * TILE_DEGREES
            west = math.floor(longitude / TILE_DEGREES) * TILE_DEGREES
            tiles.setdefault((south, west), []).append(station)
        for (south, west), records in sorted(tiles.items()):
            path = f"{name}/{south}_{west}.json"
            payloads[path] = json_bytes(records)
            manifest["tiles"].append({"catalog": name, "path": path, "south": south, "north": south + TILE_DEGREES,
                                      "west": west, "east": west + TILE_DEGREES, "count": len(records)})
    payloads["catalogs.json"] = json_bytes(manifest)
    return payloads, manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "web" / "public" / "data", help="Browser data directory")
    parser.add_argument("--check", action="store_true", help="Check existing generated files without changing them")
    args = parser.parse_args()
    payloads, manifest = build_payloads()
    existing = {str(path.relative_to(args.output)) for name in ("airports", "repeaters")
                for path in (args.output / name).glob("*.json")}
    extra = existing - set(payloads)
    if args.check:
        stale = [path for path, data in payloads.items()
                 if not (args.output / path).is_file() or (args.output / path).read_bytes() != data]
        if stale or extra:
            print(f"Browser catalogs need regeneration: {len(stale)} missing/changed files, {len(extra)} obsolete tiles.")
            return 1
    else:
        for path, data in payloads.items():
            destination = args.output / path
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
        # Only remove generated JSON tiles no longer present in the snapshots.
        for path in extra:
            (args.output / path).unlink()
    count = sum(catalog["stationCount"] for catalog in manifest["catalogs"])
    action = "Verified" if args.check else "Generated"
    print(f"{action} {count:,} unchanged station records in {len(manifest['tiles'])} geographic tiles.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
