#!/usr/bin/env python3
"""Build the unchanged receiver/DSP engine as a browser bridge shared library."""
import argparse
import os
from pathlib import Path
import platform
import shlex
import shutil
import subprocess
import sys


def main():
    root = Path(__file__).resolve().parent.parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cc", default=os.environ.get("CC"), help="C compiler (Windows: MinGW-w64 gcc)")
    parser.add_argument("--output", type=Path, help="Override output shared-library path")
    args = parser.parse_args()
    system = platform.system()
    compiler = args.cc or ("gcc" if system == "Windows" else "cc")
    command = [compiler] if shutil.which(compiler) else shlex.split(compiler, posix=system != "Windows")
    if not command or not shutil.which(command[0]):
        parser.error("C compiler missing. Install Xcode Command Line Tools (macOS), build-essential (Linux), or MSYS2 UCRT64 GCC (Windows).")
    name = {"Darwin": "libradiocore.dylib", "Windows": "radiocore.dll"}.get(system, "libradiocore.so")
    output = (args.output or root / "web" / "bridge" / "native" / name).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    command += ["-std=gnu11", "-O3", "-Wall", "-Wextra", "-pthread", "-I", str(root / "Sources/RadioCore/include")]
    command += [str(root / "Sources/RadioCore/RadioCore.c"), str(root / "Sources/RadioCore/RadioCapture.c")]
    if system == "Darwin":
        command += ["-dynamiclib", "-fPIC"]
    elif system == "Windows":
        # MinGW-w64's pthread implementation, statically linked so the deployed
        # bridge has no GCC/winpthread runtime DLL prerequisite.
        command += ["-shared", "-static", "-static-libgcc", "-Wl,--export-all-symbols"]
    else:
        command += ["-shared", "-fPIC", "-ldl"]
    command += ["-lm", "-o", str(output)]
    try:
        subprocess.run(command, check=True)
    except subprocess.CalledProcessError as error:
        return error.returncode
    print(f"Built {output}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
