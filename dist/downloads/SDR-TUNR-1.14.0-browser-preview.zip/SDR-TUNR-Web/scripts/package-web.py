#!/usr/bin/env python3
"""Package the browser app, native source, launchers and local receiver bridge."""
from pathlib import Path
import hashlib
import zipfile

root = Path(__file__).resolve().parents[1]
destination = root / 'dist' / 'web'
destination.mkdir(parents=True, exist_ok=True)
archive = destination / 'SDR-TUNR-1.14.0-browser-preview.zip'
inputs = [root / 'web', root / 'Sources' / 'RadioCore', root / 'Tests' / 'Web', root / 'research' / 'browser-preview']
files = [path for base in inputs for path in base.rglob('*') if path.is_file() and not any(part in ('__pycache__', '.DS_Store', 'site', '.git', '.sites-runtime') for part in path.parts)]
files += [root / 'scripts' / name for name in ('build-web-core.py', 'build-web-catalogs.py', 'run-web.py', 'package-web.py')]
files += [root / 'research' / name for name in ('WEB_FEATURE_PARITY.md', 'WEB_VERIFICATION.md')]
files += [root / 'Sources' / 'Tuner' / 'Resources' / name for name in ('airports.json', 'repeaters.json')]
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for path in sorted(files):
        if path.exists():
            output.write(path, 'SDR-TUNR-Web/' + path.relative_to(root).as_posix())
digest = hashlib.sha256(archive.read_bytes()).hexdigest()
archive.with_suffix('.zip.sha256').write_text(f'{digest}  {archive.name}\n')
print(f'{archive}\n{archive.stat().st_size:,} bytes\nSHA-256 {digest}')
