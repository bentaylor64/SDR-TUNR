#!/usr/bin/env python3
"""Build the small receiver core if needed, then open SDR-TUNR in a browser."""
from pathlib import Path
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
name = 'radiocore.dll' if os.name == 'nt' else 'libradiocore.dylib' if sys.platform == 'darwin' else 'libradiocore.so'
native = ROOT / 'web' / 'bridge' / 'native' / name
if not native.exists() and '--demo' not in sys.argv:
    result = subprocess.run([sys.executable, str(ROOT / 'scripts' / 'build-web-core.py')], cwd=ROOT)
    if result.returncode:
        print('\nThe receiver core could not be built. The browser will still open with connection help.\n', flush=True)
raise SystemExit(subprocess.call([sys.executable, str(ROOT / 'web' / 'bridge' / 'server.py'), '--open', *sys.argv[1:]], cwd=ROOT))
