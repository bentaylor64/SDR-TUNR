#ifndef RADIO_CORE_H
#define RADIO_CORE_H
#include <stdint.h>
#include "RadioCapture.h"

typedef struct radio_device radio_device;
typedef struct radio_dsp radio_dsp;
// Modes: 0 = narrow FM, 1 = broadcast FM (mono), 2 = AM, 3 = USB, 4 = LSB, 5 = CW (700 Hz tone).
int radio_driver_available(void);
// Configure an absolute library path before the first driver access. An explicit
// path never falls back to environment or system copies. Returns 0 if too late.
int radio_configure_driver_path(const char *path);
const char *radio_driver_error(void);
int radio_device_count(void);
void radio_device_name(int index, char *out, int size);
radio_device *radio_open(int index, char *error, int size);
void radio_close(radio_device *radio);
// Gain is in tenths of a dB; a negative value selects automatic tuner gain.
int radio_tune(radio_device *radio, uint32_t frequency, int mode, int ppm, int gain);
// Select a channel inside a fixed capture window. If center/PPM/gain match the
// active capture, only DSP changes; USB capture continues without retuning.
// Target must be within 600 kHz of center; both must be inside 25–1750 MHz.
int radio_tune_at_center(radio_device *radio, uint32_t frequency, uint32_t center, int mode, int ppm, int gain);
// Uses +Fs/4 normally and -Fs/4 near the upper edge, keeping hardware in range.
// Returns 0 for a target outside the supported 25–1750 MHz range.
uint32_t radio_tuning_center(uint32_t frequency);
// Device control and DSP are serialized on one worker. Continuous async USB
// transfers run on a separate capture thread; retunes pause sample admission and
// flush queued IQ while keeping bulk transfers alive. Close cancels and joins.
// Audio is mono 48 kHz float. radio_read requires capacity >= 512 and returns
// frames, 0 on a 250 ms capture wait timeout (check stop), or -1 on error.
int radio_read(radio_device *radio, float *audio, int capacity, float *power_db);
typedef struct {
    double input_wait_milliseconds;
    double dsp_milliseconds;
    uint64_t capture_dropped_bytes;
    int capture_high_water_blocks;
    uint32_t sample_rate;
} radio_read_metrics;
// Timing for the most recent successful read; receiver-thread access only.
radio_read_metrics radio_get_read_metrics(radio_device *radio);
typedef struct {
    const uint8_t *bytes;
    int byte_count;
    uint32_t center_frequency;
    uint32_t sample_rate;
} radio_iq_view;
// Borrowed raw pre-rotation IQ from the last successful read. Only valid until
// the next read/tune/close, and accessed on the receiver worker. Copy before
// returning from a synchronous observer if another queue will use the samples.
radio_iq_view radio_get_iq_view(radio_device *radio);
radio_dsp *radio_dsp_create(int mode);
radio_dsp *radio_dsp_create_with_offset(int mode, int center_offset_hz);
void radio_dsp_destroy(radio_dsp *dsp);
// IQ is unsigned interleaved I,Q at 1.536 MS/s. The default DSP assumes a center
// 384 kHz above the target; create_with_offset accepts offsets within ±600000 Hz.
// count is an even byte count. Allow ceil(count / 64) audio frames for streaming.
// Invalid inputs or insufficient capacity return -1 without consuming the input.
// power_db is filtered complex channel power: unit magnitude = 0 dBFS (not RF dBm).
int radio_dsp_process(radio_dsp *dsp, const uint8_t *iq, int count, float *audio, int capacity, float *power_db);
#endif
