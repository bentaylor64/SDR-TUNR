#ifndef RADIO_CAPTURE_H
#define RADIO_CAPTURE_H
#include <stdint.h>

// Small injectable transport adapter, separate from radio DSP and audio output.
enum { RADIO_CAPTURE_BYTES = 32768, RADIO_CAPTURE_BUFFERS = 8 };
typedef void (*radio_capture_callback)(unsigned char *, uint32_t, void *);
typedef int (*radio_capture_reader)(void *, radio_capture_callback, void *, uint32_t, uint32_t);
typedef int (*radio_capture_canceler)(void *);
typedef struct radio_capture radio_capture;
typedef struct {
    uint64_t received_bytes;
    uint64_t delivered_bytes;
    uint64_t dropped_bytes;
    int queued_blocks;
    int high_water_blocks;
} radio_capture_stats;

radio_capture *radio_capture_create(void *device, radio_capture_reader reader, radio_capture_canceler canceler);
// Start/stop/destroy are serialized by the controlling receiver worker.
int radio_capture_start(radio_capture *capture);
// Pause callback admission around tuner control writes without canceling bulk
// transfers. Both boundaries flush queued data; the caller still settles RF.
void radio_capture_pause(radio_capture *capture);
int radio_capture_resume(radio_capture *capture);
void radio_capture_stop(radio_capture *capture);
void radio_capture_destroy(radio_capture *capture);
// Copies into caller-owned memory. Returns bytes, zero on timeout, -1 on end/error.
int radio_capture_read(radio_capture *capture, uint8_t *output, int capacity, int timeout_ms);
radio_capture_stats radio_capture_get_stats(radio_capture *capture);
#endif
