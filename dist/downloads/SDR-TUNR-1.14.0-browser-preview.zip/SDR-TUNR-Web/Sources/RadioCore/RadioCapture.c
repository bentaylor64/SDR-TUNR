#include "RadioCapture.h"
#include <errno.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#ifdef __APPLE__
#include <sys/qos.h>
#endif

struct radio_capture {
    void *device;
    radio_capture_reader reader;
    radio_capture_canceler canceler;
    pthread_t thread;
    pthread_mutex_t mutex;
    pthread_cond_t changed;
    int thread_started, finished, stop_requested, invalid_callback, paused;
    int head, count, lengths[RADIO_CAPTURE_BUFFERS];
    uint8_t buffers[RADIO_CAPTURE_BUFFERS][RADIO_CAPTURE_BYTES];
    radio_capture_stats stats;
};

static struct timespec deadline_after(int milliseconds) {
    struct timespec deadline;
    clock_gettime(CLOCK_REALTIME, &deadline);
    deadline.tv_sec += milliseconds / 1000;
    deadline.tv_nsec += (milliseconds % 1000) * 1000000L;
    if (deadline.tv_nsec >= 1000000000L) { deadline.tv_sec++; deadline.tv_nsec -= 1000000000L; }
    return deadline;
}

// No DSP, audio scheduling or USB control here. The driver's transfer buffer is
// borrowed only for this callback; its contents are copied before it is reused.
static void received(unsigned char *bytes, uint32_t length, void *context) {
    radio_capture *c = context;
    pthread_mutex_lock(&c->mutex);
    if (!c->stop_requested && !c->invalid_callback && !c->paused && length > 0) {
        if (!bytes || length > RADIO_CAPTURE_BYTES || (length & 1)) {
            c->invalid_callback = 1;
        } else {
            c->stats.received_bytes += length;
            if (c->count == RADIO_CAPTURE_BUFFERS) {
                // Preserve a bounded live delay if DSP really falls behind.
                c->stats.dropped_bytes += c->lengths[c->head];
                c->head = (c->head + 1) % RADIO_CAPTURE_BUFFERS;
                c->count--;
            }
            int tail = (c->head + c->count) % RADIO_CAPTURE_BUFFERS;
            memcpy(c->buffers[tail], bytes, length);
            c->lengths[tail] = (int)length;
            c->count++;
            if (c->count > c->stats.high_water_blocks) c->stats.high_water_blocks = c->count;
        }
        pthread_cond_broadcast(&c->changed);
    }
    pthread_mutex_unlock(&c->mutex);
}

static void *capture_thread(void *context) {
#ifdef __APPLE__
    pthread_set_qos_class_self_np(QOS_CLASS_USER_INITIATED, 0);
#endif
    radio_capture *c = context;
    c->reader(c->device, received, c, RADIO_CAPTURE_BUFFERS, RADIO_CAPTURE_BYTES);
    pthread_mutex_lock(&c->mutex);
    c->finished = 1;
    pthread_cond_broadcast(&c->changed);
    pthread_mutex_unlock(&c->mutex);
    return NULL;
}

radio_capture *radio_capture_create(void *device, radio_capture_reader reader, radio_capture_canceler canceler) {
    if (!device || !reader || !canceler) return NULL;
    radio_capture *c = calloc(1, sizeof(*c));
    if (!c) return NULL;
    c->device = device; c->reader = reader; c->canceler = canceler;
    c->finished = 1;
    if (pthread_mutex_init(&c->mutex, NULL) != 0) { free(c); return NULL; }
    if (pthread_cond_init(&c->changed, NULL) != 0) { pthread_mutex_destroy(&c->mutex); free(c); return NULL; }
    return c;
}

int radio_capture_start(radio_capture *c) {
    if (!c || c->thread_started) return -1;
    pthread_mutex_lock(&c->mutex);
    c->head = 0; c->count = 0;
    c->stop_requested = 0; c->finished = 0; c->invalid_callback = 0; c->paused = 0;
    pthread_mutex_unlock(&c->mutex);
    if (pthread_create(&c->thread, NULL, capture_thread, c) != 0) {
        pthread_mutex_lock(&c->mutex); c->finished = 1; pthread_mutex_unlock(&c->mutex);
        return -1;
    }
    c->thread_started = 1;
    return 0;
}

void radio_capture_pause(radio_capture *c) {
    if (!c) return;
    pthread_mutex_lock(&c->mutex);
    c->paused = 1;
    c->head = 0; c->count = 0;
    pthread_mutex_unlock(&c->mutex);
}

int radio_capture_resume(radio_capture *c) {
    if (!c || !c->thread_started) return -1;
    pthread_mutex_lock(&c->mutex);
    // Flush again at the control boundary. In-flight USB transfers may still
    // contain old RF samples; the receiver's settling interval discards those.
    c->head = 0; c->count = 0;
    int usable = !c->finished && !c->stop_requested && !c->invalid_callback;
    if (usable) c->paused = 0;
    pthread_mutex_unlock(&c->mutex);
    return usable ? 0 : -1;
}

void radio_capture_stop(radio_capture *c) {
    if (!c || !c->thread_started) return;
    pthread_mutex_lock(&c->mutex);
    c->stop_requested = 1;
    pthread_cond_broadcast(&c->changed);
    pthread_mutex_unlock(&c->mutex);
    for (;;) {
        pthread_mutex_lock(&c->mutex);
        int finished = c->finished;
        pthread_mutex_unlock(&c->mutex);
        if (finished) break;
        // cancel_async may report "not running" if stop races reader startup.
        // Retry on this controlling thread until read_async has actually returned.
        // Never free buffers, retune, or close the USB handle before the join.
        c->canceler(c->device);
        struct timespec deadline = deadline_after(10);
        pthread_mutex_lock(&c->mutex);
        if (!c->finished) pthread_cond_timedwait(&c->changed, &c->mutex, &deadline);
        pthread_mutex_unlock(&c->mutex);
    }
    pthread_join(c->thread, NULL);
    c->thread_started = 0;
    pthread_mutex_lock(&c->mutex);
    c->head = 0; c->count = 0;
    pthread_mutex_unlock(&c->mutex);
}

void radio_capture_destroy(radio_capture *c) {
    if (!c) return;
    radio_capture_stop(c);
    pthread_cond_destroy(&c->changed);
    pthread_mutex_destroy(&c->mutex);
    free(c);
}

int radio_capture_read(radio_capture *c, uint8_t *output, int capacity, int timeout_ms) {
    if (!c || !output || capacity <= 0 || timeout_ms < 0) return -1;
    struct timespec deadline = deadline_after(timeout_ms);
    pthread_mutex_lock(&c->mutex);
    while (c->count == 0 && !c->finished && !c->stop_requested && !c->invalid_callback) {
        int result = pthread_cond_timedwait(&c->changed, &c->mutex, &deadline);
        if (result == ETIMEDOUT) { pthread_mutex_unlock(&c->mutex); return 0; }
        if (result != 0) { pthread_mutex_unlock(&c->mutex); return -1; }
    }
    if (c->stop_requested || c->invalid_callback || c->count == 0) {
        pthread_mutex_unlock(&c->mutex); return -1;
    }
    int length = c->lengths[c->head];
    if (capacity < length) { pthread_mutex_unlock(&c->mutex); return -1; }
    memcpy(output, c->buffers[c->head], length);
    c->head = (c->head + 1) % RADIO_CAPTURE_BUFFERS;
    c->count--;
    c->stats.delivered_bytes += length;
    pthread_mutex_unlock(&c->mutex);
    return length;
}

radio_capture_stats radio_capture_get_stats(radio_capture *c) {
    radio_capture_stats stats = {0};
    if (!c) return stats;
    pthread_mutex_lock(&c->mutex);
    stats = c->stats;
    stats.queued_blocks = c->count;
    pthread_mutex_unlock(&c->mutex);
    return stats;
}
