#include "RadioCore.h"
#include "RadioCapture.h"
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#else
#include <dlfcn.h>
#endif
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <time.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// The native app supplies its bundle-derived library path before first access.
// Standalone non-app hosts can still supply their platform's explicit override.
typedef struct rtlsdr_dev rtlsdr_dev_t;
static void *driver;
static pthread_once_t driver_once = PTHREAD_ONCE_INIT;
static pthread_mutex_t driver_config_lock = PTHREAD_MUTEX_INITIALIZER;
static char configured_driver_path[4096];
static char driver_error[1024] = "RTL-SDR library could not be loaded.";
static int driver_started;
static uint32_t (*get_count)(void);
static const char *(*get_name)(uint32_t);
static int (*usb_strings)(uint32_t, char *, char *, char *);
static int (*open_device)(rtlsdr_dev_t **, uint32_t);
static int (*close_device)(rtlsdr_dev_t *);
static int (*set_rate)(rtlsdr_dev_t *, uint32_t);
static uint32_t (*get_rate)(rtlsdr_dev_t *);
static int (*set_freq)(rtlsdr_dev_t *, uint32_t);
static uint32_t (*get_freq)(rtlsdr_dev_t *);
static int (*set_ppm)(rtlsdr_dev_t *, int);
static int (*set_gain_mode)(rtlsdr_dev_t *, int);
static int (*set_gain)(rtlsdr_dev_t *, int);
static int (*get_gains)(rtlsdr_dev_t *, int *);
static int (*reset_buffer)(rtlsdr_dev_t *);
static int (*read_async)(rtlsdr_dev_t *, radio_capture_callback, void *, uint32_t, uint32_t);
static int (*cancel_async)(rtlsdr_dev_t *);

static void *driver_open(const char *path) {
#ifdef _WIN32
    // Do not search the process working directory for executable DLLs. Python's
    // bridge explicitly adds its native directory for RTL-SDR dependencies.
    return (void *)LoadLibraryExA(path, NULL, LOAD_LIBRARY_SEARCH_DEFAULT_DIRS);
#else
    void *handle = dlopen(path, RTLD_NOW | RTLD_LOCAL);
    if (!handle) {
        const char *message = dlerror();
        snprintf(driver_error, sizeof(driver_error), "%s", message ? message : "Library load failed.");
    }
    return handle;
#endif
}
static void *driver_symbol(void *library, const char *symbol) {
#ifdef _WIN32
    return (void *)GetProcAddress((HMODULE)library, symbol);
#else
    return dlsym(library, symbol);
#endif
}
static void driver_close(void *library) {
#ifdef _WIN32
    FreeLibrary((HMODULE)library);
#else
    dlclose(library);
#endif
}
static void load_driver(void) {
    if (configured_driver_path[0]) {
        driver = driver_open(configured_driver_path);
    } else {
    // An explicit local installation wins; an invalid override must not silently
    // load another driver. The bridge requires an absolute override path.
#ifdef _WIN32
    // Preserve Windows user/install paths containing non-ASCII characters.
    const wchar_t *override = _wgetenv(L"RTLSDR_LIBRARY");
    if (override && override[0]) driver = (void *)LoadLibraryExW(override, NULL, LOAD_LIBRARY_SEARCH_DEFAULT_DIRS);
#else
    const char *override = getenv("RTLSDR_LIBRARY");
    if (override && override[0]) driver = driver_open(override);
#endif
    else {
#ifdef _WIN32
        const char *paths[] = {"rtlsdr.dll", "librtlsdr.dll"};
#elif defined(__APPLE__)
        const char *paths[] = {"librtlsdr.dylib"};
#else
        const char *paths[] = {"librtlsdr.so.0", "librtlsdr.so"};
#endif
        for (unsigned i = 0; i < sizeof(paths) / sizeof(paths[0]) && !driver; i++) driver = driver_open(paths[i]);
    }
    }
    if (!driver) return;
#define LOAD(field, symbol) *(void **)(&field) = driver_symbol(driver, symbol); if (!field) { snprintf(driver_error, sizeof(driver_error), "RTL-SDR library is missing required symbol %s.", symbol); driver_close(driver); driver = NULL; return; }
    LOAD(get_count, "rtlsdr_get_device_count")
    LOAD(get_name, "rtlsdr_get_device_name")
    LOAD(usb_strings, "rtlsdr_get_device_usb_strings")
    LOAD(open_device, "rtlsdr_open")
    LOAD(close_device, "rtlsdr_close")
    LOAD(set_rate, "rtlsdr_set_sample_rate")
    LOAD(get_rate, "rtlsdr_get_sample_rate")
    LOAD(set_freq, "rtlsdr_set_center_freq")
    LOAD(get_freq, "rtlsdr_get_center_freq")
    LOAD(set_ppm, "rtlsdr_set_freq_correction")
    LOAD(set_gain_mode, "rtlsdr_set_tuner_gain_mode")
    LOAD(set_gain, "rtlsdr_set_tuner_gain")
    LOAD(get_gains, "rtlsdr_get_tuner_gains")
    LOAD(reset_buffer, "rtlsdr_reset_buffer")
    LOAD(read_async, "rtlsdr_read_async")
    LOAD(cancel_async, "rtlsdr_cancel_async")
#undef LOAD
    driver_error[0] = 0;
}
int radio_configure_driver_path(const char *path) {
    if (!path || !path[0] || strlen(path) >= sizeof(configured_driver_path)) return 0;
#ifndef _WIN32
    if (path[0] != '/') return 0;
#endif
    pthread_mutex_lock(&driver_config_lock);
    int allowed = !driver_started;
    if (allowed) snprintf(configured_driver_path, sizeof(configured_driver_path), "%s", path);
    pthread_mutex_unlock(&driver_config_lock);
    return allowed;
}
int radio_driver_available(void) {
    pthread_mutex_lock(&driver_config_lock);
    driver_started = 1;
    pthread_mutex_unlock(&driver_config_lock);
    pthread_once(&driver_once, load_driver);
    return driver != NULL;
}
const char *radio_driver_error(void) { radio_driver_available(); return driver_error; }
int radio_device_count(void) { return radio_driver_available() ? (int)get_count() : 0; }
void radio_device_name(int index, char *out, int size) {
    if (!out || size < 1) return;
    out[0] = 0;
    if (!radio_driver_available() || index < 0 || index >= (int)get_count()) return;
    char manufacturer[256] = {0}, product[256] = {0}, serial[256] = {0};
    if (usb_strings(index, manufacturer, product, serial) == 0)
        snprintf(out, size, "%s · %s", product, serial);
    else snprintf(out, size, "%s", get_name(index));
}

#define TAPS 31
#define SIDEBAND_TAPS 255
typedef struct { float i[TAPS], q[TAPS]; int pos, phase; } decimator;
struct radio_dsp {
    int mode, rotation, rotation_step;
    double oscillator_i, oscillator_q, oscillator_step_i, oscillator_step_q;
    unsigned oscillator_samples;
    decimator stages[7], audio_stages[3];
    float sideband_i[SIDEBAND_TAPS], sideband_q[SIDEBAND_TAPS];
    float si[SIDEBAND_TAPS], sq[SIDEBAND_TAPS], sideband_level, interpolated_previous;
    int sideband_pos, cw_phase;
    float half[TAPS], channel[63], ci[63], cq[63];
    int cpos;
    float previous_i, previous_q, dc, deemphasis, audio_lowpass, am_level;
};
struct radio_device { rtlsdr_dev_t *dev; radio_dsp *dsp; radio_capture *capture; uint8_t buffer[RADIO_CAPTURE_BYTES]; int ppm, gain, last_iq_count, configured, capture_started; uint32_t sample_rate, center_frequency; radio_read_metrics metrics; };

static void make_filter(float *h, int n, float cutoff) {
    float sum = 0;
    for (int k = 0; k < n; k++) {
        float x = k - (n - 1) / 2.0f;
        h[k] = (x == 0 ? 2 * cutoff : sinf(2 * M_PI * cutoff * x) / (M_PI * x))
             * (0.42f - 0.5f * cosf(2 * M_PI * k / (n - 1)) + 0.08f * cosf(4 * M_PI * k / (n - 1)));
        sum += h[k];
    }
    for (int k = 0; k < n; k++) h[k] /= sum;
}
radio_dsp *radio_dsp_create(int mode) {
    return radio_dsp_create_with_offset(mode, 384000);
}
radio_dsp *radio_dsp_create_with_offset(int mode, int center_offset_hz) {
    if (mode < 0 || mode > 5 || center_offset_hz < -600000 || center_offset_hz > 600000) return NULL;
    radio_dsp *s = calloc(1, sizeof(*s));
    if (!s) return NULL;
    s->mode = mode;
    s->rotation_step = center_offset_hz == 384000 ? 1 : center_offset_hz == -384000 ? 3 : center_offset_hz == 0 ? 0 : -1;
    s->oscillator_i = 1;
    double angle = 2 * M_PI * center_offset_hz / 1536000.0;
    s->oscillator_step_i = cos(angle); s->oscillator_step_q = sin(angle);
    make_filter(s->half, TAPS, 0.23f);
    make_filter(s->channel, 63, mode == 1 ? 100000.0f / 384000 : (mode == 2 ? 5000.0f : 6500.0f) / 48000);
    if (mode >= 3) {
        // USB/LSB: 300–3000 Hz on the selected side of the carrier, at 12 kHz.
        // CW: a 500 Hz channel centered on the displayed carrier frequency.
        float lowpass[SIDEBAND_TAPS];
        make_filter(lowpass, SIDEBAND_TAPS, (mode == 5 ? 250.0f : 1350.0f) / 12000);
        float center = mode == 3 ? 1650 : mode == 4 ? -1650 : 0;
        for (int k = 0; k < SIDEBAND_TAPS; k++) {
            double phase = 2 * M_PI * center * (k - (SIDEBAND_TAPS - 1) / 2) / 12000;
            s->sideband_i[k] = lowpass[k] * cos(phase);
            s->sideband_q[k] = lowpass[k] * sin(phase);
        }
    }
    return s;
}
void radio_dsp_destroy(radio_dsp *s) { free(s); }
static int decimate(decimator *d, const float *h, float *i, float *q) {
    d->i[d->pos] = *i; d->q[d->pos] = *q;
    int pos = d->pos;
    d->pos = (d->pos + 1) % TAPS;
    d->phase ^= 1;
    if (d->phase) return 0;
    float a = 0, b = 0;
    for (int k = 0; k < TAPS; k++) { a += h[k] * d->i[pos]; b += h[k] * d->q[pos]; if (--pos < 0) pos = TAPS - 1; }
    *i = a; *q = b;
    return 1;
}
int radio_dsp_process(radio_dsp *s, const uint8_t *iq, int count, float *audio, int capacity, float *power_db) {
    if (!s || !iq || !audio || !power_db || capacity <= 0 || count < 0 || (count & 1)) return -1;
    int stages = s->mode == 1 ? 2 : s->mode >= 3 ? 7 : 5;
    // Reject a short output buffer before consuming any IQ or changing filter state.
    // Each phase is a pending sample in its divide-by-two stage.
    int frames = count / 2;
    for (int k = 0; k < stages; k++) frames = (frames + s->stages[k].phase) / 2;
    if (s->mode == 1)
        for (int k = 0; k < 3; k++) frames = (frames + s->audio_stages[k].phase) / 2;
    if (s->mode >= 3) frames *= 4;
    if (frames > capacity) return -1;
    int written = 0, powers = 0;
    double power = 0;
    for (int n = 0; n + 1 < count; n += 2) {
        float i = (iq[n] - 127.5f) / 128, q = (iq[n + 1] - 127.5f) / 128;
        if (s->rotation_step >= 0) {
            // Preserve the inexpensive quarter-rate path for ordinary channel scans.
            float temp = i;
            switch (s->rotation) { case 1: i = -q; q = temp; break; case 2: i = -i; q = -q; break; case 3: i = q; q = -temp; break; }
            s->rotation = (s->rotation + s->rotation_step) & 3;
        } else {
            // Tune within a stationary capture window before filtering/decimation.
            // The oscillator remains phase-continuous across input blocks.
            float temp = i;
            i = (float)(i * s->oscillator_i - q * s->oscillator_q);
            q = (float)(temp * s->oscillator_q + q * s->oscillator_i);
            double next_i = s->oscillator_i * s->oscillator_step_i - s->oscillator_q * s->oscillator_step_q;
            s->oscillator_q = s->oscillator_i * s->oscillator_step_q + s->oscillator_q * s->oscillator_step_i;
            s->oscillator_i = next_i;
            if ((++s->oscillator_samples & 4095) == 0) {
                double magnitude = hypot(s->oscillator_i, s->oscillator_q);
                s->oscillator_i /= magnitude; s->oscillator_q /= magnitude;
            }
        }
        int ready = 1;
        for (int k = 0; k < stages; k++) if (!decimate(&s->stages[k], s->half, &i, &q)) { ready = 0; break; }
        if (!ready) continue;
        if (s->mode >= 3) {
            s->si[s->sideband_pos] = i; s->sq[s->sideband_pos] = q;
            int pos = s->sideband_pos;
            float filtered_i = 0, filtered_q = 0;
            for (int k = 0; k < SIDEBAND_TAPS; k++) {
                filtered_i += s->si[pos] * s->sideband_i[k] - s->sq[pos] * s->sideband_q[k];
                filtered_q += s->si[pos] * s->sideband_q[k] + s->sq[pos] * s->sideband_i[k];
                if (--pos < 0) pos = SIDEBAND_TAPS - 1;
            }
            s->sideband_pos = (s->sideband_pos + 1) % SIDEBAND_TAPS;
            float p = filtered_i * filtered_i + filtered_q * filtered_q;
            power += p; powers++;
            float level = sqrtf(p);
            s->sideband_level += (level > s->sideband_level ? 0.02f : 0.0001f) * (level - s->sideband_level);
            float sample = filtered_i;
            if (s->mode == 5) {
                // A carrier at the selected frequency becomes a 700 Hz Morse tone.
                double phase = 2 * M_PI * s->cw_phase / 120;
                sample = filtered_i * cos(phase) - filtered_q * sin(phase);
                s->cw_phase = (s->cw_phase + 7) % 120;
            }
            sample *= fminf(50, 0.25f / fmaxf(s->sideband_level, 0.005f));
            // Return the same continuous 48 kHz format used by every mode.
            for (int k = 1; k <= 4; k++) {
                float interpolated = s->interpolated_previous + (sample - s->interpolated_previous) * (k / 4.0f);
                s->dc += 0.002f * (interpolated - s->dc);
                s->audio_lowpass += 0.37f * (interpolated - s->dc - s->audio_lowpass);
                audio[written++] = fmaxf(-0.95f, fminf(0.95f, s->audio_lowpass));
            }
            s->interpolated_previous = sample;
            continue;
        }
        s->ci[s->cpos] = i; s->cq[s->cpos] = q;
        int pos = s->cpos; i = 0; q = 0;
        for (int k = 0; k < 63; k++) { i += s->channel[k] * s->ci[pos]; q += s->channel[k] * s->cq[pos]; if (--pos < 0) pos = 62; }
        s->cpos = (s->cpos + 1) % 63;
        float p = i * i + q * q;
        power += p; powers++;
        float sample;
        if (s->mode == 2) {
            float envelope = sqrtf(p);
            s->am_level += 0.0005f * (envelope - s->am_level);
            sample = (envelope - s->am_level) / fmaxf(s->am_level, 0.005f) * 0.35f;
        } else {
            float cross = q * s->previous_i - i * s->previous_q;
            float dot = i * s->previous_i + q * s->previous_q;
            sample = atan2f(cross, dot) * (s->mode == 1 ? 384000.0f / (2 * M_PI * 75000) : 48000.0f / (2 * M_PI * 5000)) * 0.45f;
        }
        s->previous_i = i; s->previous_q = q;
        if (s->mode == 1) {
            float unused = 0;
            for (int k = 0; k < 3; k++) if (!decimate(&s->audio_stages[k], s->half, &sample, &unused)) { ready = 0; break; }
            if (!ready) continue;
            // North American broadcast FM de-emphasis (75 microseconds).
            s->deemphasis += 0.242535f * (sample - s->deemphasis);
            sample = s->deemphasis;
        }
        s->dc += 0.002f * (sample - s->dc);
        sample -= s->dc;
        // Smooth demodulated audio; narrow modes use a voice-band low-pass pole.
        float alpha = s->mode == 1 ? 0.86f : 0.37f;
        s->audio_lowpass += alpha * (sample - s->audio_lowpass);
        audio[written++] = fmaxf(-0.95f, fminf(0.95f, s->audio_lowpass));
    }
    *power_db = powers ? 10 * log10f(fmaxf((float)(power / powers), 1e-12f)) : -120;
    return written;
}
static void set_error(char *error, int size, const char *message) {
    if (error && size > 0) snprintf(error, size, "%s", message);
}
static int capture_reader(void *device, radio_capture_callback callback, void *context, uint32_t buffers, uint32_t bytes) {
    return read_async(device, callback, context, buffers, bytes);
}
static int capture_canceler(void *device) { return cancel_async(device); }
radio_device *radio_open(int index, char *error, int size) {
    set_error(error, size, "");
    if (!radio_driver_available()) {
        set_error(error, size, configured_driver_path[0]
                  ? "Bundled receiver software is missing, damaged or incompatible. Reinstall the complete SDR-TUNR app, then reopen it."
                  : "RTL-SDR driver not found. Install librtlsdr for your operating system.");
        return NULL;
    }
    if (index < 0 || (uint32_t)index >= get_count()) { set_error(error, size, "No receiver found. Connect your NESDR Mini and try again."); return NULL; }
    radio_device *r = calloc(1, sizeof(*r));
    if (!r) { set_error(error, size, "Not enough memory to start the receiver."); return NULL; }
    if (open_device(&r->dev, (uint32_t)index) < 0) { set_error(error, size, "Receiver busy or unavailable. Close other SDR apps and reconnect the USB receiver."); free(r); return NULL; }
    if (set_rate(r->dev, 1536000) < 0 || set_gain_mode(r->dev, 0) < 0) {
        set_error(error, size, "The receiver could not start sampling."); radio_close(r); return NULL;
    }
    r->sample_rate = get_rate(r->dev);
    if (r->sample_rate != 1536000) {
        set_error(error, size, "The receiver did not accept the required 1.536 MS/s sample rate."); radio_close(r); return NULL;
    }
    r->capture = radio_capture_create(r->dev, capture_reader, capture_canceler);
    if (!r->capture) { set_error(error, size, "Could not allocate the receiver capture buffers."); radio_close(r); return NULL; }
    return r;
}
void radio_close(radio_device *r) { if (!r) return; radio_capture_destroy(r->capture); if (r->dev) close_device(r->dev); radio_dsp_destroy(r->dsp); free(r); }
uint32_t radio_tuning_center(uint32_t frequency) {
    if (frequency < 25000000 || frequency > 1750000000) return 0;
    return frequency <= 1750000000 - 384000 ? frequency + 384000 : frequency - 384000;
}
int radio_tune(radio_device *r, uint32_t frequency, int mode, int ppm, int gain) {
    return radio_tune_at_center(r, frequency, radio_tuning_center(frequency), mode, ppm, gain);
}
int radio_tune_at_center(radio_device *r, uint32_t frequency, uint32_t center, int mode, int ppm, int gain) {
    if (!r || !r->dev || frequency < 25000000 || frequency > 1750000000 ||
        center < 25000000 || center > 1750000000 || llabs((int64_t)center - frequency) > 600000 || mode < 0 || mode > 5) return -1;
    radio_dsp *next = radio_dsp_create_with_offset(mode, (int)center - (int)frequency);
    if (!next) return -6;
    // Only the selected channel changes. Raw IQ and its waterfall axis stay fixed.
    if (r->configured && r->dsp && r->center_frequency == center && r->ppm == ppm && r->gain == gain) {
        radio_dsp_destroy(r->dsp); r->dsp = next;
        r->last_iq_count = 0;
        return 0;
    }
    // Keep one async bulk stream for the receiver session. Repeated Darwin
    // cancel/restart cycles have produced callbacks into freed libusb transfers.
    // Tuner control writes use the control endpoint while callback admission is
    // paused. No reset_buffer is sent against an active bulk endpoint.
    radio_capture_pause(r->capture);
    r->last_iq_count = 0;
    int change_gain = !r->configured || r->gain != gain;
    r->configured = 0; // A failed control write must never leave a usable fast path.
    r->center_frequency = 0;
    int failure = -2;
    if (ppm != r->ppm) { if (set_ppm(r->dev, ppm) < 0) goto failed; r->ppm = ppm; }
    if (change_gain) {
        failure = -3;
        if (set_gain_mode(r->dev, gain < 0 ? 0 : 1) < 0) goto failed;
        if (gain >= 0) {
            int n = get_gains(r->dev, NULL);
            if (n <= 0 || n > 256) goto failed;
            int gains[256];
            int returned = get_gains(r->dev, gains);
            if (returned != n) goto failed;
            int nearest = gains[0];
            for (int j = 1; j < n; j++)
                if (llabs((long long)gains[j] - gain) < llabs((long long)nearest - gain)) nearest = gains[j];
            if (set_gain(r->dev, nearest) < 0) goto failed;
        }
    }
    failure = -4;
    if (set_freq(r->dev, center) < 0 || get_freq(r->dev) != center) goto failed;
    if (!r->capture_started) {
        failure = -5;
        if (reset_buffer(r->dev) < 0) goto failed;
        failure = -7;
        if (radio_capture_start(r->capture) < 0) goto failed;
        r->capture_started = 1;
    } else {
        failure = -7;
        if (radio_capture_resume(r->capture) < 0) goto failed;
    }
    radio_dsp_destroy(r->dsp); r->dsp = next;
    r->gain = gain; r->center_frequency = center; r->configured = 1;
    return 0;
failed:
    // Existing bulk capture stays paused until a successful retune or close.
    // It never delivers old-channel data after a partially applied setting.
    radio_dsp_destroy(next);
    return failure;
}
static double monotonic_milliseconds(void) {
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);
    return now.tv_sec * 1000.0 + now.tv_nsec / 1000000.0;
}
radio_read_metrics radio_get_read_metrics(radio_device *r) {
    return r ? r->metrics : (radio_read_metrics){0};
}
radio_iq_view radio_get_iq_view(radio_device *r) {
    if (!r || r->last_iq_count <= 0) return (radio_iq_view){0};
    return (radio_iq_view){r->buffer, r->last_iq_count, r->center_frequency, r->sample_rate};
}
int radio_read(radio_device *r, float *audio, int capacity, float *power_db) {
    if (!r || !r->dev || !r->dsp || !audio || !power_db || capacity < 512) return -1;
    r->last_iq_count = 0;
    double before_usb = monotonic_milliseconds();
    int count = radio_capture_read(r->capture, r->buffer, sizeof(r->buffer), 250);
    double before_dsp = monotonic_milliseconds();
    if (count == 0) return 0; // Give the controlling worker a chance to stop.
    if (count < 0 || count > (int)sizeof(r->buffer) || (count & 1)) return -1;
    int frames = radio_dsp_process(r->dsp, r->buffer, count, audio, capacity, power_db);
    if (frames > 0) r->last_iq_count = count;
    r->metrics.input_wait_milliseconds = before_dsp - before_usb;
    r->metrics.dsp_milliseconds = monotonic_milliseconds() - before_dsp;
    radio_capture_stats stats = radio_capture_get_stats(r->capture);
    r->metrics.capture_dropped_bytes = stats.dropped_bytes;
    r->metrics.capture_high_water_blocks = stats.high_water_blocks;
    r->metrics.sample_rate = r->sample_rate;
    return frames;
}
