# Browser preview verification · 1.14.0

Verified September 16, 2026 on macOS 26.6.2, Apple silicon, using Brave 153.1.95.101 (Chromium), Python 3.9 and the installed RTL-SDR library. Windows compilation and Windows USB reception have not been tested. This preview's [feature coverage](WEB_FEATURE_PARITY.md) is narrower than the native app.

## Outcome

The real RTL2838UHIDIR receiver was detected and streamed through the native C bridge, socket worker and browser AudioWorklet. FM, WFM, AM, USB, LSB and CW ran, and a 1 Hz CW adjustment preserved the hardware capture center. The test kept browser volume muted and checked nonzero audio samples before the volume control. It establishes hardware capture and playback transport, **not intelligible station reception or audible quality**.

The initial driver enumeration found no device. A receiver subsequently appeared. The first browser open was refused with `usb_claim_interface error -3`; a direct driver open-and-close then succeeded, and the browser retry passed. No other radio app was terminated and no system driver settings were changed. Treat future access refusals as real errors, not as successful detection or an invitation to substitute demo data.

During the brief real-hardware acceptance run (approximately 3.5 seconds per mode, plus startup and fine tuning):

| Mode | Frequency | Last observed playback queue | Reported underruns | Reported audio/capture drops |
| --- | --- | --- | --- | --- |
| FM | 162.550 MHz | 59 ms | 0 | 0 |
| WFM | 99.500 MHz | 56 ms | 0 | 0 |
| AM | 125.000 MHz | 56 ms | 0 | 0 |
| USB | 28.400 MHz | 53 ms | 0 | 0 |
| LSB | 28.400 MHz | 53 ms | 0 | 0 |
| CW | 28.050 MHz | 61 ms | 0 | 0 |

These are sampled queue depths and software counters on this Mac. They are not end-to-end latency, a long-duration reliability result, calibrated RF measurements, or performance predictions for a Windows PC. The receiver was explicitly stopped and released after testing. See [raw hardware results](browser-preview/hardware-results.json) and [live hardware screenshot](browser-preview/hardware-live.png).

## Browser acceptance

The explicit synthetic test server exercised controls and streaming independently of station conditions. It was stopped afterward; the regular preview uses the real driver. The final synthetic run reported a 53 ms audio queue, zero underruns, zero drops and zero browser errors after 12 seconds of uninterrupted playback. Its page initially fetched about 119 KB of resource bodies (excluding the main HTML), with no airport or repeater catalog request at startup.

Passed checks:

- Real AudioWorklet output measured before the muted volume control.
- Live FFT and waterfall at 1.2 MHz, 300 kHz and 75 kHz widths.
- Stationary frequency axis during fine tuning, exact six-decimal MHz entry, and a 1 Hz increment.
- Favorite save, exact frequency/mode retention, and reload persistence.
- Band selection changes the receiving mode.
- A one-pass channel scan reports measured candidates and finishes.
- A fixed ZIP response fixture leads to actual bundled local directory records (11 recommended candidates for the test location); this does not verify live Zippopotam.us service availability.
- Desktop and 390-pixel mobile layouts render without horizontal overflow.
- Explicit demo labeling, including on mobile; normal mode does not show a demo badge.

See [browser results](browser-preview/browser-results.json) and [mobile screenshot](browser-preview/mobile.png). `Tests/Web/browser-smoke.cjs` and `Tests/Web/hardware-smoke.cjs` reproduce these checks when Playwright and a Chromium executable are supplied. The hardware test intentionally fails unless a real device opens; it never enables demo mode.

## Brave Start follow-up

The user's existing Brave window initially showed a generic bridge-disconnected message when Start was pressed. The app reserved the single receiver connection on page load, kept it after Stop, and replaced useful rejection details with a generic socket-close message. Audio initialization could also wait indefinitely. These defects were corrected: page load performs a read-only probe, Start acquires the connection and waits for the matching receiver acknowledgment, Stop releases it, busy errors survive socket closure, and audio initialization has a bounded deadline with cleanup for retry.

After restarting the bridge and refreshing the user's actual Brave tab, live SDR reception and the updating spectrum were verified. Stop released ownership while that tab remained open, and a second Start succeeded. The Connections panel reported 61 ms queued audio, zero underruns and zero dropped frames during this brief check. No browser security settings were changed. The tab was left stopped with its original unmuted 65% volume restored. This check used the computer-use browser connection; the earlier acceptance runs below used Playwright.

A separate automated attempt to open a second Brave tab returned `ERR_BLOCKED_BY_CLIENT`; no protection was bypassed. Simultaneous-tab rejection and ownership preservation are covered by bridge tests, rather than a completed two-tab UI test. The exact original Brave failure was not isolated to a single cause; the confirmed result is successful live reception in the existing Brave tab after the lifecycle fixes.

## Public preview

The static public preview uses a separate, explicitly labeled synthetic tone and spectrum, with no bridge or hardware requests. Its Start/Stop flow, demo spectrum and hardware setup links were checked in the browser without console errors. Real reception uses the downloadable local package. The public page disables channel scanning and hardware controls; browser-only demo output does not verify the native DSP or USB path. A generated-package check excludes the hosted checkout and previously staged downloads, preventing nested archives.

## Automated checks

- **255 native tests in 31 suites pass**, retaining the existing 1.14.0 receiver behavior.
- **52 browser model/audio/lifecycle tests pass.** These cover exact tuning, all native service centers, lossless catalog copying, ZIP cancellation, favorites, playback queue limits, resampling, spectrum orientation, cancelled starts, read-only probes, busy preflight, Stop/restart ownership, acknowledged startup, startup deadlines and retry, preserved rejection messages, a suspended audio message port, and hosted-demo isolation/cancellation/cleanup.
- **18 bridge tests pass.** These cover command validation, Host/Origin/token boundaries, a single receiver owner, actionable duplicate-session rejection, availability during slow close, sanitized diagnostics, binary streaming, tune reset ordering, smooth squelch, disconnect cleanup, malformed frames, and bounded queues.
- Native capture's **6 sanitizer tests** and persistent-retune lifecycle check pass under AddressSanitizer/UndefinedBehaviorSanitizer.
- macOS shared-library compilation passes. The locally compiled core is 52,960 bytes.
- Catalog regeneration verification preserves **27,440 unchanged records in 621 geographic tiles**, with source provenance.

Socket tests require loopback networking; the initial sandbox prevented binding. They passed when run with loopback access. The dedicated `agent-browser` executable was unavailable; browser verification used the installed Playwright library and Brave executable directly.

## Offline DSP budget

300 measured 32,768-byte blocks per mode after 30 warmups, each representing 10.667 ms of incoming samples. This benchmark includes only native processing plus the calling overhead, not USB capture, Python transport, UI rendering or the audio device.

| Mode | Mean processing | p99 processing | Mean fraction of one real-time CPU core |
| --- | --- | --- | --- |
| FM | 0.514 ms | 0.619 ms | 4.8% |
| WFM | 0.878 ms | 1.029 ms | 8.2% |
| AM | 0.507 ms | 0.610 ms | 4.8% |
| USB | 0.511 ms | 0.620 ms | 4.8% |
| LSB | 0.511 ms | 0.632 ms | 4.8% |
| CW | 0.518 ms | 0.650 ms | 4.9% |

[Raw benchmark results](browser-preview/dsp-benchmark.json). CPU headroom is encouraging, but a target-PC session with the actual WinUSB/librtlsdr installation and a known station remains necessary before calling Windows support verified.
