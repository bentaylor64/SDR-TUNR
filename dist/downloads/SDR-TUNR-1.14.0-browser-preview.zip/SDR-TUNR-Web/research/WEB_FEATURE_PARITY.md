# Browser preview coverage against native 1.14.0

This is a browser preview based on the 1.14.0 receiver core and listening plans. It is not a complete replacement for the native app. Physical USB capture and browser audio transport passed in all six modes on this Mac with volume muted; Windows hardware and intelligible station audio remain unverified. See [verification evidence](WEB_VERIFICATION.md).

| Native capability | Browser preview coverage | Remaining difference |
| --- | --- | --- |
| RTL-SDR capture, FM / WFM / AM / USB / LSB / CW demodulation | The local bridge calls the existing C receiver engine. Browser audio runs in an AudioWorklet. All six modes streamed through the real SDR on macOS. | A matching operating-system RTL-SDR library and USB driver must be installed. Windows compilation, Windows hardware and intelligible reception require separate acceptance testing. |
| 25–1750 MHz manual tuning | All integer-Hz values in the native range are accepted. | Actual receiver coverage still depends on hardware. Browser input rejects fractional Hz rather than silently rounding. |
| Fine tuning introduced in 1.14.0 | Twelve native band choices, exact receive channel plans, normal/fine precision, mode-specific increments, independent step selections, and preservation of an existing Hz offset. | Direct entry additionally accepts explicit Hz/kHz/MHz units. Free tuning does not identify a transmitter. |
| Weather, GMRS, FRS, MURS, Rail, Marine plans | Exact native centers and service labels. Disjoint groups stay disjoint; excluded marine data centers and GMRS repeater inputs are not added. | US receive plans only. A listed channel does not imply a local transmission or establish its modulation. |
| Nearby airports and repeaters | All 18,338 FAA airport entries and 9,102 HearHam entries from the native snapshot, including original source metadata. | Snapshots are not a live directory service. Geographic tiles load only after nearby discovery is requested. HearHam download dates are not verification dates. |
| ZIP-based discovery | Zippopotam.us lookup, coordinate validation, distance/radius/search filtering, nearest-towered-airport recommendations, cancellation and stale-response rejection. National plans work without lookup. | Location is an approximate ZIP center. This module does not add continuous geolocation, a remote account or background directory updates. |
| Favorites | Browser-local, validated favorites preserve names, exact frequencies and receiving modes. Corrupted entries do not discard valid rows. | Storage is scoped to browser profile and origin, including localhost port. Native macOS UserDefaults are not imported automatically. |
| Live spectrum and waterfall | The browser uses worker-based FFT processing and bounded display/audio queues. | Browser spectrum cadence and rendering differ from native. Queue bounds are design limits, not measured end-to-end latency. |
| Native Explore band survey / Find presets | Browser channel checking visits exact listed tuning targets and reports measured power only. Native broad 2 m / 70 cm scan target lists are available in the model. | No continuous full-band survey reconstruction, off-grid peak detection, native candidate prominence ranking, or equivalent native one-pass coverage validation. Do not describe a channel check as a full native band survey. |
| Native continuous scanning, hold, skip and resume | A bounded single-pass channel checker is supplied for the browser interface. | Native continuous multi-band/favorite scanning policy, hold/release timing and all resume semantics are not fully ported. |
| Manual squelch and receiver controls | The bridge accepts the receiver controls exposed by the preview. | Native automatic squelch calibration and remembered per-listening-profile sensitivity are not implemented in the browser layer. |
| ADS-B aircraft mode and map | Not ported. | No browser aircraft decoding, live map, trails, selected-aircraft details, route or photograph lookups. |
| Morse text panel | CW demodulation is provided by the shared receiver engine. | Native best-effort Morse text decoder and its panel are not ported. CW audio alone is not Morse text decoding. |
| Equipment onboarding, antenna recommendations, listening conditions | Not ported. | Native equipment directory, setup persistence, antenna range matching and propagation guidance remain native features. |
| Recording, trunk tracking and other digital protocols | Not added. | These are not introduced by a browser permission picker or by the local bridge. |

## USB and serial boundary

The functioning receiver path is browser → loopback bridge → installed RTL-SDR library → USB hardware. A web page cannot load an arbitrary PC driver DLL. Optional WebUSB identification is a separate user-authorized identity check; it does not implement the RTL2832U tuner/control protocol or stream receiver samples. RTL-SDR does not expose its sample stream as a serial port, so granting Web Serial access would not make it receive radio.

The bridge must be running on the computer physically connected to the SDR. Publishing these files on a static website does not give that website access to a remote user's installed radio drivers. See the browser setup document for the supported path and operating-system prerequisites.

## Directory payload and provenance

`web/public/data/catalogs.json` records the original snapshot metadata and SHA-256 of each native source file. The 27,440 unchanged records are partitioned into 621 geographic tiles of 2° latitude × 2° longitude. National channel plans are a small module; importing the directory module performs no network requests. A local search fetches the approximately 70 KB manifest and relevant tiles only, with at most four tile requests in flight and a 64-tile in-memory cache. A latitude/longitude bounding box selects candidates, then great-circle distance applies the actual radius.

The airport snapshot retains the FAA NASR cycle, original source files/hashes, OurAirports attribution and public-domain metadata. Repeater entries retain the HearHam source link and download date. The partitioning does not refresh, verify or infer any station information. `Tests/Web/model.test.mjs` compares every tiled record to the native snapshot and checks its source hash, tile location and unique identifier.

## Verification represented by the model tests

The browser model/directory tests cover exact Hz input/output, native marine-table parity, service counts and gaps, band/mode changes, channel endpoint behavior, receiver limits, anchored precision snapping, remembered step selections, favorite corruption/quota failures, radius/search filters, geographic edge cases, cancellation, stale responses and lossless catalog copying. They do not establish USB access, demodulated audio intelligibility, browser latency on the user's PC, or feature parity for the missing native systems listed above.
