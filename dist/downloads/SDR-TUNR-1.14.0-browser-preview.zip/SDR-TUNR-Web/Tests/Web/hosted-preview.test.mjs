import { test } from 'node:test';
import assert from 'node:assert/strict';
import { HostedDemoTransport } from '../../web/public/hosted-preview.js';

test('hosted demo starts without network or hardware and stops all generated work', async () => {
  const originalAudio = globalThis.AudioContext, originalFetch = globalThis.fetch;
  let started = 0, stopped = 0, closed = 0;
  globalThis.fetch = () => { throw new Error('Hosted demo must not request a bridge'); };
  globalThis.AudioContext = class {
    state = 'running'; currentTime = 0;
    createGain() { return { gain: { value: 0, setTargetAtTime() {} }, connect() {} }; }
    createOscillator() { return { frequency: { setTargetAtTime() {} }, connect() {}, start() { started++; }, stop() { stopped++; } }; }
    async resume() {}
    async close() { closed++; this.state = 'closed'; }
  };
  const transport = new HostedDemoTransport();
  const settings = { frequency: 162550000, mode: 'FM', squelch: -60 };
  try {
    assert.equal((await transport.probe()).demo, true);
    assert.deepEqual((await transport.devices()).devices, []);
    transport.setSpectrum(true);
    assert.equal(await transport.start(settings), true);
    assert.equal(started, 1); assert.ok(transport.timer);
    let frame;
    transport.addEventListener('spectrum', event => { frame = event.detail; });
    transport.frame();
    assert.equal(frame.bins.length, 1024);
    assert.ok(frame.bins.every(Number.isFinite));
    transport.setSpectrum(false); assert.equal(transport.timer, null);
    await transport.stop();
    assert.equal(transport.running, false); assert.equal(stopped, 1);
    assert.equal(await transport.start(settings), true);
    transport.close();
    assert.equal(started, 2); assert.equal(stopped, 2); assert.equal(closed, 1);
  } finally {
    transport.close(); globalThis.AudioContext = originalAudio; globalThis.fetch = originalFetch;
  }
});

test('Stop cancels a hosted demo whose browser audio permission is still pending', async () => {
  const transport = new HostedDemoTransport();
  let ready;
  transport.prepareAudio = () => new Promise(resolve => { ready = resolve; });
  const start = transport.start({ frequency: 162550000, mode: 'FM' });
  await transport.stop(); ready();
  assert.equal(await start, false);
  assert.equal(transport.running, false);
  assert.equal(transport.oscillator, null);
});
