// Run with NODE_PATH pointing to an installed Playwright package. Requires the
// explicit --demo bridge on 8781. Never opens a real receiver.
const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs');
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.SDR_BROWSER || '/Applications/Brave Browser.app/Contents/MacOS/Brave Browser', headless: true });
  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  const page = await context.newPage(), errors = [], requests = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
  page.on('request', request => requests.push(request.url()));
  await page.addInitScript(() => {
    window.__audioNodes = [];
    const Node = window.AudioWorkletNode;
    window.AudioWorkletNode = class extends Node { constructor(...args) { super(...args); window.__audioNodes.push(this); } };
  });
  try {
    await page.goto(process.env.SDR_TEST_URL || 'http://127.0.0.1:8781');
    await page.waitForFunction(() => document.getElementById('bridge-status').textContent.includes('Connected'));
    assert.equal(await page.locator('#demo-badge').isVisible(), true, 'Requires explicitly labelled demo server');
    assert.equal(requests.filter(url => url.includes('/data/')).length, 0, 'No catalogs at startup');
    const initialBytes = await page.evaluate(() => performance.getEntriesByType('resource').reduce((sum, entry) => sum + entry.encodedBodySize, 0));
    // The worklet signal is measured before browser volume; speakers stay muted.
    await page.locator('#mute-button').click();
    await page.locator('#start-button').click();
    await page.waitForFunction(() => document.getElementById('receiver-state').textContent === 'Listening live');
    await page.waitForFunction(() => document.getElementById('spectrum-empty').hidden);
    await page.evaluate(() => {
      const node = window.__audioNodes.at(-1);
      window.__analyser = node.context.createAnalyser();
      node.connect(window.__analyser);
    });
    await page.waitForFunction(() => {
      const samples = new Float32Array(window.__analyser.fftSize);
      window.__analyser.getFloatTimeDomainData(samples);
      return samples.some(value => Math.abs(value) > 0.01);
    });
    await page.waitForTimeout(12000);
    const audio = await page.evaluate(() => ({ queued: document.getElementById('metric-queue').textContent, underruns: document.getElementById('metric-underruns').textContent, dropped: document.getElementById('metric-dropped').textContent }));
    assert.ok(Number.parseFloat(audio.queued) <= 160, 'Audio queue bounded');
    await page.locator('#spectrum-width').selectOption('75000');
    await page.waitForFunction(() => document.getElementById('spectrum-span').textContent.includes('75 kHz'));
    const stationaryAxis = await page.locator('#frequency-axis').innerText();
    await page.locator('#fine-toggle').check();
    await page.locator('#tune-down').click();
    await page.waitForFunction(() => document.getElementById('receiver-frequency').textContent === '162.5499');
    await page.waitForTimeout(300);
    assert.equal(await page.locator('#frequency-axis').innerText(), stationaryAxis, 'Fine tuning preserves zoomed axis');
    await page.locator('#spectrum-width').selectOption('300000');
    await page.waitForFunction(() => document.getElementById('spectrum-span').textContent.includes('300 kHz'));
    await page.locator('#spectrum-width').selectOption('1200000');
    await page.waitForFunction(() => document.getElementById('spectrum-span').textContent.includes('1.2 MHz'));
    await page.screenshot({ path: '/tmp/sdr-web-live.png', fullPage: true });
    await page.locator('#mode-select').selectOption('CW');
    await page.locator('#exact-frequency').fill('28.050001');
    await page.locator('#exact-form').evaluate(form => form.requestSubmit());
    await page.waitForFunction(() => document.getElementById('receiver-frequency').textContent === '28.050001');
    await page.locator('#fine-toggle').check();
    await page.getByRole('button', { name: '1 Hz tuning step', exact: true }).click();
    await page.locator('#tune-up').click();
    await page.waitForFunction(() => document.getElementById('receiver-frequency').textContent === '28.050002');
    await page.locator('#save-button').click();
    await page.locator('#favorite-name').fill('Browser precision test');
    await page.locator('#favorite-form').evaluate(form => form.requestSubmit());
    await page.locator('[data-page="favorites"]').click();
    assert.ok((await page.locator('#favorites-list').innerText()).includes('28.050002'));
    await page.locator('[data-page="explore"]').click();
    await page.locator('#band-select').selectOption('weather');
    await page.waitForFunction(() => document.getElementById('mode-select').value === 'FM');
    await page.locator('#scan-button').click();
    await page.waitForFunction(() => document.getElementById('scan-button').textContent === 'Scan channels', { timeout: 20000 });
    assert.ok((await page.locator('.scan-results').innerText()).includes('162.'));
    await page.locator('#start-button').click();
    await page.waitForFunction(() => document.getElementById('receiver-state').textContent === 'Receiver stopped');
    await page.route('https://api.zippopotam.us/us/49125', route => route.fulfill({ json: { 'post code': '49125', 'country abbreviation': 'US', places: [{ 'place name': 'Sawyer', 'state abbreviation': 'MI', latitude: '41.8845', longitude: '-86.5886' }] } }));
    await page.locator('[data-page="nearby"]').click();
    await page.locator('#zip-code').fill('49125');
    await page.locator('#location-form').evaluate(form => form.requestSubmit());
    await page.waitForFunction(() => document.getElementById('location-label').textContent.includes('Sawyer'));
    await page.waitForFunction(() => document.querySelectorAll('#station-list .station-row').length > 7);
    const directoryRows = await page.locator('#station-list .station-row').count();
    await page.reload();
    await page.waitForFunction(() => document.getElementById('bridge-status').textContent.includes('Connected'));
    await page.locator('[data-page="favorites"]').click();
    assert.ok((await page.locator('#favorites-list').innerText()).includes('Browser precision test'));
    await page.setViewportSize({ width: 390, height: 844 });
    await page.locator('[data-page="explore"]').click();
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth > innerWidth + 1);
    assert.equal(overflow, false, 'No mobile horizontal overflow');
    await page.screenshot({ path: '/tmp/sdr-web-mobile.png', fullPage: true });
    assert.deepEqual(errors, []);
    const result = { status: 'passed', initialResourceBytes: initialBytes, audio, directoryRows, errors,
      checks: ['actual worklet audio from demo', 'bounded queue after 12s', 'live FFT and all 3 widths', 'stationary axis during fine tune', 'exact Hz and 1Hz increment', 'favorite save/reload', 'band mode', 'measured channel scan', 'ZIP fixture to real local catalogs', 'mobile overflow'] };
    fs.writeFileSync('/tmp/sdr-web-browser-results.json', JSON.stringify(result, null, 2));
    console.log(JSON.stringify(result, null, 2));
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
