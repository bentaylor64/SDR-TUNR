import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { BANDS, MIN_FREQUENCY, MAX_FREQUENCY, MODES, parseFrequency, formatFrequency, getBand, channelPlan,
  scanChannels, resolveProfile, adjacentFrequency, snappedFrequency, selectBand, FineTuningSelection,
  validateFavorite, loadFavorites, saveFavorites, FAVORITES_KEY } from '../../web/public/radio-model.js';
import { RadioDirectory, nationalStations, distanceMiles, matchesStation, validateStation, validLocation,
  tileMayIntersect } from '../../web/public/directory.js';

test('MHz and explicit-unit entry preserve individual Hz without floating point rounding', () => {
  const values = ['25.000001', '50.090013', '162.475123', '462.5625', '1749.999999', '1750'];
  const expected = [25000001, 50090013, 162475123, 462562500, 1749999999, 1750000000];
  values.forEach((value, index) => assert.equal(parseFrequency(value), expected[index]));
  assert.equal(parseFrequency(' 162.475123 MHz '), 162475123);
  assert.equal(parseFrequency('162475.123 kHz'), 162475123);
  assert.equal(parseFrequency('162475123 Hz'), 162475123);
  assert.equal(parseFrequency('162,475123'), 162475123);
  assert.equal(parseFrequency('162.475123000'), 162475123);
  for (const frequency of expected) assert.equal(parseFrequency(formatFrequency(frequency)), frequency);
  assert.equal(formatFrequency(100000000), '100.000');
  assert.equal(formatFrequency(162475123), '162.475123');
});

test('invalid frequency entry never wraps, clamps or silently loses precision', () => {
  for (const value of ['', 'NaN', 'Infinity', '1e2', '-25', '24.999999', '1750.000001', '162.4751234',
    '162475123.1 Hz', '162 475 MHz', '162.47.5', '25.0foo', '9007199254740991 Hz', null, 162.475]) {
    assert.equal(parseFrequency(value), null, String(value));
  }
});

test('all twelve 1.14.0 bands have valid bounds, defaults and modes', () => {
  assert.deepEqual(BANDS.map(band => band.id), ['fm', 'air', '2m', '70cm', 'weather', 'gmrs', 'rail', 'marine', 'murs', 'frs', '10m', '6m']);
  for (const band of BANDS) {
    assert.ok(band.lowerFrequency >= MIN_FREQUENCY && band.upperFrequency <= MAX_FREQUENCY);
    assert.ok(band.defaultFrequency >= band.lowerFrequency && band.defaultFrequency <= band.upperFrequency);
    assert.ok(MODES.includes(band.defaultMode));
  }
});

test('service plans preserve exact native counts, gaps and exclusions', () => {
  for (const [id, count] of Object.entries({ fm: 100, air: 760, weather: 7, gmrs: 22, frs: 22, murs: 5, rail: 91, marine: 39 })) {
    const channels = channelPlan(id);
    assert.equal(channels.length, count, id);
    assert.equal(new Set(channels.map(channel => channel.frequency)).size, count, id);
    assert.ok(channels.every((channel, index) => index === 0 || channel.frequency > channels[index - 1].frequency));
  }
  assert.deepEqual(channelPlan('gmrs').map(value => value.frequency), channelPlan('frs').map(value => value.frequency));
  assert.deepEqual(channelPlan('murs').map(value => value.frequency), [151820000, 151880000, 151940000, 154570000, 154600000]);
  assert.equal(channelPlan('rail').at(-1).frequency, 161565000);
  assert.equal(channelPlan('air').at(-1).frequency, 136975000);
  assert.equal(channelPlan('gmrs').at(-1).frequency, 467712500);
  assert.ok(!channelPlan('gmrs').some(value => value.frequency === 467550000));
  for (const frequency of [156525000, 161975000, 162025000]) assert.ok(!channelPlan('marine').some(value => value.frequency === frequency));
  assert.ok(channelPlan('marine').some(value => value.frequency === 161600000));
});

test('marine names, purposes and receive centers exactly match native 1.14.0 source', async () => {
  const source = await readFile(new URL('../../Sources/Tuner/ServiceChannelPlans.swift', import.meta.url), 'utf8');
  const marine = source.split('static let marine:')[1];
  const native = [...marine.matchAll(/\.init\(frequency: ([\d_]+), label: "([^"]+)", detail: "([^"]+)"\)/g)]
    .map(([, frequency, label, detail]) => ({ frequency: Number(frequency.replaceAll('_', '')), label, detail }));
  assert.equal(native.length, 39);
  assert.deepEqual(channelPlan('marine'), native);
});

test('service context uses nearby exact channels, never an entire separated envelope', () => {
  for (const [band, frequency] of [['murs', 152000000], ['gmrs', 464000000], ['frs', 466000000],
    ['marine', 158000000], ['marine', 156525000], ['marine', 161975000], ['marine', 162025000]]) {
    const profile = resolveProfile(frequency, 'FM', band);
    assert.equal(profile.title, 'Free tuning');
    assert.equal(profile.channels.length, 0);
    assert.equal(profile.normalDefault, 5000);
  }
  assert.equal(resolveProfile(160500000, 'FM', 'marine').title, 'Rail');
  for (const id of ['weather', 'gmrs', 'frs', 'murs', 'rail', 'marine']) {
    const center = getBand(id).defaultFrequency;
    for (const delta of [-100, 100, 1000]) assert.equal(resolveProfile(center + delta, 'FM', id).title, getBand(id).title);
  }
  assert.equal(resolveProfile(462562500, 'FM', 'frs').title, 'FRS');
  assert.equal(resolveProfile(462562500, 'FM', 'gmrs').title, 'GMRS');
  assert.equal(resolveProfile(151820000, 'FM', 'frs').title, 'MURS');
});

test('channel stepping jumps service gaps without inventing channels and stops at endpoints', () => {
  for (const [id, lower, upper] of [['murs', 151940000, 154570000], ['gmrs', 462725000, 467562500],
    ['marine', 156500000, 156550000], ['marine', 157425000, 161600000], ['rail', 160215000, 160230000]]) {
    const profile = resolveProfile(lower, 'FM', id);
    assert.equal(adjacentFrequency(lower, 1, 'channel', profile), upper);
    assert.equal(adjacentFrequency(upper, -1, 'channel', profile), lower);
    assert.equal(adjacentFrequency(profile.channels[0].frequency, -1, 'channel', profile), null);
    assert.equal(adjacentFrequency(profile.channels.at(-1).frequency, 1, 'channel', profile), null);
  }
});

test('numeric steps retain individual Hz and enforce both receiver limits', () => {
  const profile = resolveProfile(50090013, 'CW');
  assert.ok(profile.fineSteps.includes(1));
  assert.equal(adjacentFrequency(50090013, 1, 1, profile), 50090014);
  assert.equal(adjacentFrequency(50090013, -1, 10, profile), 50090003);
  for (const [frequency, direction, step] of [[MIN_FREQUENCY, -1, 1], [MAX_FREQUENCY, 1, 1],
    [MIN_FREQUENCY + 50, -1, 100], [100000000, 0, 100], [100000000, 1, 0], [100000000, 1, -100], [100000000, 1, NaN]]) {
    assert.equal(adjacentFrequency(frequency, direction, step, profile), null);
  }
  assert.equal(adjacentFrequency(MAX_FREQUENCY - 100, 1, 100, profile), MAX_FREQUENCY);
});

test('numeric drag snaps relative to original frequency instead of erasing fine offsets', () => {
  const profile = resolveProfile(162475123, 'FM');
  const range = [162474000, 162476000];
  assert.equal(snappedFrequency(162475377, 100, 162475123, range, profile), 162475423);
  assert.equal(snappedFrequency(162474000, 100, 162475123, range, profile), 162474023);
  assert.equal(snappedFrequency(162480000, 100, 162475123, range, profile), 162475923);
  assert.equal(snappedFrequency(162475500, 1000, 162475123, [162475200, 162475900], profile), null);
  assert.equal(snappedFrequency(162475073, 100, 162475123, range, profile), 162475023, 'native rounding at negative half tick');
  for (const value of [NaN, Infinity, -Infinity]) assert.equal(snappedFrequency(value, 100, 162475123, range, profile), null);
  assert.equal(snappedFrequency(20000000, 100, 25000000, [10000000, 24000000], profile), null);
});

test('channel drag cannot fabricate an off-plan center inside a viewport', () => {
  const profile = resolveProfile(151940000, 'FM', 'murs');
  assert.equal(snappedFrequency(152000000, 'channel', 151940000, [151900000, 154580000], profile), 151940000);
  assert.equal(snappedFrequency(153000000, 'channel', 151940000, [152000000, 154000000], profile), null);
});

test('narrow mode precision and selection are remembered independently per profile', () => {
  const selection = new FineTuningSelection();
  const weather = resolveProfile(162475123, 'FM', 'weather');
  const cw = resolveProfile(50090013, 'CW', '6m');
  assert.equal(selection.step(weather), 'channel');
  selection.select(5000, weather);
  selection.fine = true;
  assert.equal(selection.step(weather), 100);
  selection.select(10, weather);
  assert.equal(selection.step(cw), 10);
  selection.select(1, cw);
  assert.equal(selection.step(weather), 10);
  selection.fine = false;
  assert.equal(selection.step(weather), 5000);
  for (const mode of ['USB', 'LSB', 'CW']) {
    const profile = resolveProfile(99500000, mode);
    assert.equal(profile.normalDefault, 100);
    assert.ok(!profile.normalSteps.includes('channel'));
  }
});

test('selecting a band selects its default mode and keeps only allowed service channels', () => {
  assert.deepEqual(selectBand('marine', 161600000), { frequency: 161600000, mode: 'FM' });
  assert.deepEqual(selectBand('marine', 156525000), { frequency: 156800000, mode: 'FM' });
  assert.deepEqual(selectBand('air', 162500000), { frequency: 125000000, mode: 'AM' });
  assert.deepEqual(selectBand('fm', 99500123), { frequency: 99500123, mode: 'WFM' });
  assert.deepEqual(selectBand('10m', 99500000), { frequency: 28400000, mode: 'USB' });
  assert.equal(selectBand('invalid', 99500000), null);
});

test('native broad ham scan plans remain distinct from fine-tuning channel plans', () => {
  assert.equal(channelPlan('2m').length, 0);
  const twoMeter = scanChannels('2m');
  assert.equal(twoMeter.length, 290);
  assert.equal(twoMeter[0].frequency, 145100000);
  assert.equal(twoMeter.at(-1).frequency, 147990000);
  assert.equal(scanChannels('70cm').length, 400);
  assert.equal(scanChannels('murs').length, 5);
  assert.equal(scanChannels('10m').length, 0, 'no unsupported measured sweep is implied');
  assert.ok(twoMeter.every(channel => channel.mode === 'FM' && !('power' in channel)));
});

test('favorite validation salvages valid rows without trusting malformed storage', () => {
  const good = { id: 'saved-1', name: ' NOAA ', frequency: 162475123, mode: 'FM', bandName: ' Weather ' };
  assert.deepEqual(validateFavorite(good), { ...good, name: 'NOAA', bandName: 'Weather' });
  assert.equal(validateFavorite({ ...good, frequency: 162475123.5 }), null);
  assert.equal(validateFavorite({ ...good, mode: 'AUTO' }), null);
  assert.equal(validateFavorite({ ...good, id: '' }), null);
  assert.equal(validateFavorite({ ...good, frequency: 17499999999 }), null);
  const storage = { getItem: () => JSON.stringify([null, good, good, { ...good, id: 'broken', mode: 'BAD' }]) };
  assert.equal(loadFavorites(storage).length, 1);
  assert.deepEqual(loadFavorites({ getItem: () => '{broken' }), []);
  assert.deepEqual(loadFavorites({ getItem: () => '{"not":"a list"}' }), []);
  assert.deepEqual(loadFavorites({ getItem: () => { throw new Error('Access denied'); } }), []);
  assert.equal(saveFavorites([good], { setItem: () => { throw new Error('quota exceeded'); } }), false);
  const writes = [];
  assert.equal(saveFavorites([good], { setItem: (...args) => writes.push(args) }), true);
  assert.equal(writes[0][0], FAVORITES_KEY);
  assert.equal(JSON.parse(writes[0][1])[0].frequency, 162475123);
});

const location = { zip: '48197', city: 'Ypsilanti', state: 'MI', latitude: 42.2411, longitude: -83.6129 };
const station = { id: 'airport-1', name: 'Willow Run · Tower', frequency: 125275000, mode: 'AM', category: 'airports',
  detail: 'Tower voice', sourceName: 'FAA NASR', sourceURL: 'https://www.faa.gov/', updatedAt: '2026-09-03',
  latitude: 42.2379, longitude: -83.5304, airportID: 'YIP', iataCode: 'YIP', service: 'tower' };
const repeater = { ...station, id: 'ham-1', name: 'Local repeater', frequency: 146900000, mode: 'FM', category: 'ham',
  sourceName: 'HearHam', sourceURL: 'https://hearham.com/repeaters', airportID: undefined, iataCode: undefined, service: undefined };
const fixtureManifest = { version: 1, catalogs: [{ id: 'airports', sourceName: 'FAA NASR' }, { id: 'repeaters', sourceName: 'HearHam' }], tiles: [
  { catalog: 'airports', path: 'airports/42_-84.json', south: 42, north: 44, west: -84, east: -82 },
  { catalog: 'repeaters', path: 'repeaters/42_-84.json', south: 42, north: 44, west: -84, east: -82 },
  { catalog: 'airports', path: 'airports/32_-118.json', south: 32, north: 34, west: -118, east: -116 },
] };
const response = (value, status = 200) => ({ ok: status >= 200 && status < 300, status, json: async () => value });
function fixtureDirectory() {
  const requests = [];
  const directory = new RadioDirectory({ baseURL: 'https://localhost/data/', fetchImpl: async url => {
    const path = new URL(url).pathname;
    requests.push(path);
    if (path.endsWith('catalogs.json')) return response(fixtureManifest);
    if (path.endsWith('repeaters/42_-84.json')) return response([repeater]);
    if (path.endsWith('airports/42_-84.json')) return response([station, { ...station, id: 'invalid', frequency: 1 },
      { ...station, id: 'farther', latitude: 43.8 }, { ...station, id: 'invalid-link', sourceURL: 'javascript:alert(1)' }]);
    throw new Error(`Unexpected fetch: ${path}`);
  } });
  return { directory, requests };
}

test('national channel plans are available offline with no catalog fetch or invented positions', async () => {
  const { directory, requests } = fixtureDirectory();
  assert.equal((await directory.find({ category: 'weather', location })).length, 7);
  assert.equal((await directory.find({ category: 'gmrs' })).length, 22);
  assert.equal((await directory.find({ category: 'murs', location })).length, 5);
  assert.equal((await directory.find({ category: 'recommended' })).length, 7);
  assert.deepEqual(requests, []);
  assert.ok(nationalStations('marine').every(value => value.isNationwide && value.distanceMiles === null && !('latitude' in value)));
});

test('directory loads only relevant geographic tiles, validates rows and sorts real distances', async () => {
  const { directory, requests } = fixtureDirectory();
  const result = await directory.find({ category: 'airports', location, radiusMiles: 35, search: 'YIP tower' });
  assert.equal(result.length, 1);
  assert.equal(result[0].id, station.id);
  assert.ok(result[0].distanceMiles > 4 && result[0].distanceMiles < 5);
  assert.deepEqual(requests, ['/data/catalogs.json', '/data/airports/42_-84.json']);
  assert.equal((await directory.find({ category: 'airports', location, frequencyRange: [118000000, 124000000] })).length, 0);
  assert.equal(requests.length, 2, 'completed tiles are reused');
  assert.equal(directory.catalogs[0].sourceName, 'FAA NASR');
});

test('recommended directory keeps nearest towered airport, measured distances and national fallback', async () => {
  const { directory } = fixtureDirectory();
  const result = await directory.find({ category: 'recommended', location });
  assert.equal(result[0].category, 'weather');
  assert.equal(result[1].id, station.id);
  assert.equal(result[2].id, repeater.id);
  assert.equal(result.length, 9);
  assert.ok(result.every(value => !('signalDetected' in value) && !('power' in value)));
});

test('directory filtering folds accents, requires every word and accepts precise frequency searches', () => {
  assert.ok(matchesStation({ ...station, name: 'Aéroport Côte' }, 'aero cote'));
  assert.ok(matchesStation(station, 'YIP 125.275'));
  assert.ok(!matchesStation(station, 'YIP nonexistent'));
  assert.equal(validateStation({ ...station, latitude: NaN }), null);
  assert.equal(validateStation({ ...station, mode: 'DSTAR' }), null);
  assert.equal(validateStation({ ...station, sourceURL: 'data:text/html,hi' }), null);
  assert.equal(validLocation({ ...location, longitude: 181 }), false);
  assert.equal(distanceMiles(location, location), 0);
  assert.equal(distanceMiles(location, { latitude: Infinity, longitude: 0 }), Infinity);
});

test('directory tile selection includes boundary, date-line and polar neighborhoods', () => {
  assert.ok(tileMayIntersect({ south: 42, north: 44, west: -84, east: -82 }, location, 35));
  assert.ok(!tileMayIntersect({ south: 32, north: 34, west: -118, east: -116 }, location, 35));
  assert.ok(tileMayIntersect({ south: 50, north: 52, west: -180, east: -178 }, { latitude: 51, longitude: 179.9 }, 35));
  assert.ok(tileMayIntersect({ south: 88, north: 90, west: 20, east: 22 }, { latitude: 89.9, longitude: -160 }, 35));
});

const zipPayload = (zip = location.zip) => ({ 'country abbreviation': 'US', 'post code': zip, places: [{
  'place name': location.city, 'state abbreviation': location.state, latitude: String(location.latitude), longitude: String(location.longitude),
}] });
test('ZIP lookup validates input, response identity and coordinates', async () => {
  const directory = new RadioDirectory({ fetchImpl: async () => response(zipPayload()) });
  assert.deepEqual(await directory.lookupZIP('48197'), { ...location, label: 'Ypsilanti, MI · 48197' });
  await assert.rejects(directory.lookupZIP('4819'), /five-digit/);
  await assert.rejects(directory.lookupZIP('48198'), /incomplete/);
  const malformed = new RadioDirectory({ fetchImpl: async () => response({ ...zipPayload(), places: [{ ...zipPayload().places[0], latitude: '' }] }) });
  await assert.rejects(malformed.lookupZIP('48197'), /incomplete/);
  const missing = new RadioDirectory({ fetchImpl: async () => response({}, 404) });
  await assert.rejects(missing.lookupZIP('48197'), /not found/);
});

test('editing ZIP input cancels old responses even if fetch ignores AbortSignal', async () => {
  let complete;
  const directory = new RadioDirectory({ fetchImpl: () => new Promise(resolve => { complete = resolve; }) });
  const pending = directory.lookupZIP('48197');
  directory.cancelLookup();
  complete(response(zipPayload()));
  await assert.rejects(pending, error => error.name === 'AbortError');
});

test('superseded directory requests cannot restore stale results', async () => {
  let complete;
  const directory = new RadioDirectory({ baseURL: 'https://localhost/data/', fetchImpl: () => new Promise(resolve => { complete = resolve; }) });
  const previous = directory.find({ location, category: 'airports' });
  const current = await directory.find({ category: 'weather' });
  assert.equal(current.length, 7);
  complete(response(fixtureManifest));
  await assert.rejects(previous, error => error.name === 'AbortError');
});

test('bundled tiled catalogs preserve every native snapshot record and its source metadata', async () => {
  const base = new URL('../../web/public/data/', import.meta.url);
  const manifest = JSON.parse(await readFile(new URL('catalogs.json', base), 'utf8'));
  for (const name of ['airports', 'repeaters']) {
    const originalBytes = await readFile(new URL(`../../Sources/Tuner/Resources/${name}.json`, import.meta.url));
    const original = JSON.parse(originalBytes);
    const catalog = manifest.catalogs.find(value => value.id === name);
    assert.equal(catalog.sourceSHA256, createHash('sha256').update(originalBytes).digest('hex'));
    assert.equal(catalog.stationCount, original.stations.length);
    assert.equal(catalog.sourceURL, original.sourceURL);
    const actual = new Map();
    for (const tile of manifest.tiles.filter(value => value.catalog === name)) {
      const records = JSON.parse(await readFile(new URL(tile.path, base), 'utf8'));
      assert.equal(records.length, tile.count);
      for (const record of records) {
        assert.ok(record.latitude >= tile.south && record.latitude < tile.north);
        assert.ok(record.longitude >= tile.west && record.longitude < tile.east);
        assert.ok(!actual.has(record.id));
        actual.set(record.id, record);
      }
    }
    assert.equal(actual.size, original.stations.length);
    for (const record of original.stations) assert.deepEqual(actual.get(record.id), record);
  }
});
