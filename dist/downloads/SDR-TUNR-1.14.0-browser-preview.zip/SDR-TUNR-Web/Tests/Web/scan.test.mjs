import test from 'node:test';
import assert from 'node:assert/strict';
import { ChannelScanner } from '../../web/public/scanner.js';

const deferred = () => {
  let resolve;
  const promise = new Promise(value => { resolve = value; });
  return { promise, resolve };
};
const settings = { frequency: 162475000, mode: 'FM', squelch: -60 };
class PendingAudioTransport extends EventTarget {
  constructor() { super(); this.ready = deferred(); this.volume = 0.5; this.starts = []; this.tunes = []; }
  prepareAudio() { return this.ready.promise; }
  setVolume(value) { this.volume = value; }
  async start(value) { this.starts.push(value); throw new Error('Stop fixture after observing start'); }
  async tune(value) { this.tunes.push(value); }
}

test('cancelling while browser audio permission is pending prevents a later scan start', async () => {
  const transport = new PendingAudioTransport();
  const scanner = new ChannelScanner(transport);
  const pending = scanner.start([{ frequency: 162400000, mode: 'FM' }], settings);
  await scanner.cancel(false);
  transport.ready.resolve();
  await pending;
  assert.equal(transport.starts.length, 0);
  assert.equal(transport.tunes.length, 0);
  assert.equal(transport.volume, 0.5);
});

test('two scans requested during audio initialization allow only the newest request to start', async () => {
  const transport = new PendingAudioTransport();
  const scanner = new ChannelScanner(transport);
  const first = scanner.start([{ frequency: 162400000, mode: 'FM' }], settings);
  const second = scanner.start([{ frequency: 162550000, mode: 'FM' }], settings);
  transport.ready.resolve();
  await Promise.all([first, second]);
  assert.deepEqual(transport.starts.map(value => value.frequency), [162550000]);
  assert.equal(transport.volume, 0.5);
  assert.equal(scanner.run, null);
});
