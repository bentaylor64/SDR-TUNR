// Explicit physical receiver check, always muted. Does not prove intelligibility.
const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs');
(async () => {
  const browser = await chromium.launch({ executablePath: process.env.SDR_BROWSER || '/Applications/Brave Browser.app/Contents/MacOS/Brave Browser', headless: true });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } }), errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.addInitScript(() => {
    window.__statuses = []; window.__receiverErrors = []; window.__nodes = [];
    const WorkerClass = window.Worker;
    window.Worker = class extends WorkerClass {
      constructor(...args) {
        super(...args);
        this.addEventListener('message', ({ data }) => {
          if (data.type === 'status') { window.__statuses.push(data); if (window.__statuses.length > 600) window.__statuses.shift(); }
          if (data.type === 'error') window.__receiverErrors.push(data.message);
        });
      }
    };
    const AudioNodeClass = window.AudioWorkletNode;
    window.AudioWorkletNode = class extends AudioNodeClass { constructor(...args) { super(...args); window.__nodes.push(this); } };
  });
  try {
    await page.goto(process.env.SDR_TEST_URL || 'http://127.0.0.1:8780');
    await page.waitForFunction(() => document.getElementById('bridge-status').textContent.includes('Connected'));
    assert.equal(await page.locator('#demo-badge').isVisible(), false);
    await page.locator('#detect-button').click();
    await page.waitForFunction(() => !document.getElementById('detect-button').disabled);
    const devices = await page.evaluate(async () => (await (await fetch('/api/devices')).json()));
    assert.ok(devices.devices.length > 0, 'A real SDR must be connected for this check');
    await page.locator('#mute-button').click();
    await page.locator('#squelch').evaluate(input => { input.value = -120; input.dispatchEvent(new Event('input', { bubbles: true })); });
    await page.locator('#start-button').click();
    await page.waitForFunction(() => window.__statuses.some(s => s.running) || window.__receiverErrors.length);
    assert.deepEqual(await page.evaluate(() => window.__receiverErrors), []);
    await page.waitForFunction(() => document.getElementById('spectrum-empty').hidden);
    await page.evaluate(() => {
      const node = window.__nodes.at(-1); window.__analyser = node.context.createAnalyser(); node.connect(window.__analyser);
    });
    await page.waitForFunction(() => {
      const samples = new Float32Array(window.__analyser.fftSize); window.__analyser.getFloatTimeDomainData(samples);
      return samples.some(value => Math.abs(value) > 0.00001);
    });
    const modes = [];
    for (const [mode, frequency] of [['FM', '162.550'], ['WFM', '99.500'], ['AM', '125.000'], ['USB', '28.400'], ['LSB', '28.400'], ['CW', '28.050']]) {
      await page.locator('#mode-select').selectOption(mode);
      await page.locator('#exact-frequency').fill(frequency);
      await page.locator('#exact-form').evaluate(form => form.requestSubmit());
      await page.waitForFunction(({ mode, hz }) => window.__statuses.at(-1)?.running && window.__statuses.at(-1)?.mode === mode && window.__statuses.at(-1)?.frequency === hz, { mode, hz: Math.round(Number(frequency) * 1e6) });
      await page.waitForTimeout(3500);
      modes.push(await page.evaluate(() => ({ ...window.__statuses.at(-1), queue: document.getElementById('metric-queue').textContent, underruns: document.getElementById('metric-underruns').textContent, dropped: document.getElementById('metric-dropped').textContent })));
    }
    const center = modes.at(-1).center;
    await page.locator('#fine-toggle').check();
    await page.getByRole('button', { name: '1 Hz tuning step', exact: true }).click();
    await page.locator('#tune-up').click();
    await page.waitForFunction(() => window.__statuses.at(-1)?.frequency === 28050001);
    assert.equal(await page.evaluate(() => window.__statuses.at(-1).center), center, 'Native capture center remains fixed for 1Hz adjustment');
    await page.waitForTimeout(3000);
    await page.screenshot({ path: '/tmp/sdr-web-hardware-live.png', fullPage: true });
    assert.deepEqual(await page.evaluate(() => window.__receiverErrors), []);
    assert.deepEqual(errors, []);
    await page.locator('#start-button').click();
    await page.waitForFunction(() => window.__statuses.at(-1)?.running === false);
    const result = { status: 'passed', devices, modes, errors, note: 'Physical USB capture and browser audio transport verified on this Mac with volume muted. RF noise or samples do not establish intelligible stations. Windows hardware was not tested.' };
    fs.writeFileSync('/tmp/sdr-web-hardware-results.json', JSON.stringify(result, null, 2));
    console.log(JSON.stringify(result, null, 2));
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
