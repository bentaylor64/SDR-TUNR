import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFileSync } from 'node:fs';
import { spectrum } from '../../web/public/spectrum-worker.js';

function playback(rate = 48000) {
  let Processor;
  const scope = { Float32Array, Number, Math, sampleRate: rate,
    AudioWorkletProcessor: class { constructor() { this.port = { postMessage() {} }; } },
    registerProcessor(name, implementation) { Processor = implementation; } };
  vm.runInNewContext(readFileSync(new URL('../../web/public/audio-worklet.js', import.meta.url), 'utf8'), scope);
  return new Processor();
}
function feed(player, count, value = 0.5) {
  player.receive({ type: 'pcm', buffer: new Float32Array(count).fill(value).buffer });
}
function render(player, count = 128) {
  const out = new Float32Array(count);
  player.process([], [[out]]);
  return out;
}
test('spectrum ignores incomplete IQ windows without nonfinite values', () => {
  assert.equal(spectrum(new Uint8Array(4)).length, 0);
  assert.equal(spectrum(new Uint8Array(0)).length, 0);
});
test('playback waits for reserve and produces actual samples', () => {
  const p = playback(); feed(p, 2048);
  assert.ok(render(p).every(v => v === 0));
  feed(p, 1024);
  assert.ok(render(p).every(v => v === 0.5));
  assert.equal(p.count, 2944);
});
test('backpressure discards oldest sound and queue stays bounded', () => {
  const p = playback(); feed(p, 7000, 0.2); feed(p, 2048, 0.7);
  assert.equal(p.count, 3072); assert.equal(p.droppedFrames, 5976);
  for (let i = 0; i < 8; i++) render(p);
  assert.ok(render(p).every(v => Math.abs(v - 0.7) < 1e-6));
  feed(p, 30000); assert.ok(p.count <= p.maximum);
});
test('retune flushes all prior samples; underrun returns silence and re-buffers', () => {
  const p = playback(); feed(p, 3072); render(p);
  p.receive({ type: 'reset' }); assert.equal(p.count, 0);
  assert.ok(render(p).every(v => v === 0));
  feed(p, 3072); for (let i = 0; i < 30; i++) render(p);
  assert.equal(p.underruns, 1); assert.ok(render(p).every(v => v === 0));
  feed(p, 3072, 0.3); assert.equal(p.playing, true);
});
test('48k input is resampled when device audio clock differs', () => {
  const p = playback(96000); feed(p, 4096); render(p, 1024);
  assert.equal(p.count, 3584);
  const q = playback(44100); feed(q, 4096); render(q, 441);
  assert.ok(Math.abs(q.count - (4096 - 480)) <= 1);
});
test('invalid PCM does not send NaN to speakers', () => {
  const p = playback(); feed(p, 3072, NaN);
  assert.ok(render(p).every(Number.isFinite));
});
for (const offset of [-300, 250]) test(`spectrum locates ${offset}-bin complex tone on correct side`, () => {
  const n = 4096, iq = new Uint8Array(n * 2);
  for (let i = 0; i < n; i++) {
    iq[2 * i] = Math.round(127.5 + 100 * Math.cos(2 * Math.PI * offset * i / n));
    iq[2 * i + 1] = Math.round(127.5 + 100 * Math.sin(2 * Math.PI * offset * i / n));
  }
  const bins = spectrum(iq);
  const maximum = bins.reduce((best, value, i) => value > bins[best] ? i : best, 0);
  assert.equal(maximum, n / 2 + offset);
  assert.ok(Math.abs(bins[maximum] - 20 * Math.log10(100 / 128)) < 0.1);
  assert.ok(bins.every(Number.isFinite));
});
