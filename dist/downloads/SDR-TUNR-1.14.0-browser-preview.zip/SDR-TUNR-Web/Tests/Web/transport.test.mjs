import test from 'node:test';
import assert from 'node:assert/strict';
import { ReceiverTransport } from '../../web/public/transport.js';
import vm from 'node:vm';
import { readFileSync } from 'node:fs';
function deferred() { let resolve, reject; const promise = new Promise((yes, no) => { resolve = yes; reject = no; }); return { promise, resolve, reject }; }
async function withGlobals(values, callback) {
  const originals = Object.fromEntries(Object.keys(values).map(key => [key, Object.getOwnPropertyDescriptor(globalThis, key)]));
  for (const [key, value] of Object.entries(values)) Object.defineProperty(globalThis, key, { configurable: true, writable: true, value });
  try { return await callback(); }
  finally {
    for (const [key, descriptor] of Object.entries(originals)) {
      if (descriptor) Object.defineProperty(globalThis, key, descriptor);
      else delete globalThis[key];
    }
  }
}
function audioFixture({ resume, module } = {}) {
  const contexts = [];
  class AudioContext {
    constructor() {
      this.state = 'suspended'; this.closed = 0; this.destination = {};
      contexts.push(this);
      this.audioWorklet = { addModule: () => module?.(this, contexts.length) || Promise.resolve() };
    }
    async resume() { await resume?.(this, contexts.indexOf(this) + 1); if (this.state !== 'closed') this.state = 'running'; }
    async close() { this.closed++; this.state = 'closed'; }
    createGain() { return { gain: { value: 0 }, connect() { return this; } }; }
  }
  class AudioWorkletNode {
    constructor() { this.port = { postMessage() {} }; }
    connect(target) { return target; }
  }
  return { contexts, globals: { AudioContext, AudioWorkletNode } };
}
test('Stop during audio authorization never starts a receiver afterward', async () => {
  const t = new ReceiverTransport(), audio = deferred(), sent = [];
  t.prepareAudio = () => audio.promise;
  t.connect = async () => { t.connected = true; };
  t.attachAudio = () => {};
  t.send = command => sent.push(command);
  const pending = t.start({ frequency: 100100000, mode: 'WFM' });
  await t.stop(); audio.resolve();
  assert.equal(await pending, false); assert.deepEqual(sent, []);
});
test('Stop while socket connection is pending prevents late start', async () => {
  const t = new ReceiverTransport(), socket = deferred(), sent = [];
  t.prepareAudio = async () => {};
  t.connect = () => socket.promise;
  t.attachAudio = () => {};
  t.send = command => sent.push(command);
  const pending = t.start({ frequency: 100100000, mode: 'WFM' });
  await Promise.resolve(); await t.stop(); socket.resolve();
  assert.equal(await pending, false); assert.deepEqual(sent, []);
});
test('only latest concurrent Start request reaches the receiver', async () => {
  const t = new ReceiverTransport(), audio = deferred(), sent = [];
  t.prepareAudio = () => audio.promise;
  t.connect = async () => { t.connected = true; };
  t.attachAudio = () => {};
  t.send = command => {
    sent.push(command);
    t.emit('status', { running: true, reset: true, frequency: command.frequency, mode: command.mode });
  };
  const first = t.start({ frequency: 100100000, mode: 'WFM' });
  const last = t.start({ frequency: 162550000, mode: 'FM' });
  audio.resolve(); await Promise.all([first, last]);
  assert.equal(sent.length, 1); assert.equal(sent[0].frequency, 162550000);
});
test('read-only bridge probe does not create a worker or claim receiver ownership', async () => {
  const requests = [];
  await withGlobals({
    fetch: async (url, options) => { requests.push({ url, options }); return { ok: true, json: async () => ({ token: 'test', receiverBusy: false }) }; },
    Worker: class { constructor() { assert.fail('A bridge probe must not create a socket worker'); } },
  }, async () => {
    const t = new ReceiverTransport();
    const session = await t.probe();
    assert.equal(session.receiverBusy, false);
    assert.equal(t.session, session); assert.equal(t.worker, null); assert.equal(t.connected, false);
    assert.equal(requests.length, 1); assert.equal(requests[0].url, '/api/session');
    assert.equal(requests[0].options.cache, 'no-store');
  });
});
test('busy bridge preflight explains which browser must release the receiver without opening a socket', async () => {
  await withGlobals({
    fetch: async () => ({ ok: true, json: async () => ({ token: 'test', receiverBusy: true }) }),
    Worker: class { constructor() { assert.fail('Busy preflight must not create a socket worker'); } },
  }, async () => {
    const t = new ReceiverTransport();
    await assert.rejects(t.connect(), /in use in another browser tab.*Stop it there/i);
    assert.equal(t.worker, null); assert.equal(t.connected, false); assert.equal(t.connecting, null);
  });
});
test('Stop releases the socket but retains initialized browser audio for the next click', async () => {
  const t = new ReceiverTransport(), messages = [], audioMessages = [], statuses = [];
  const context = { close() { assert.fail('Stop must preserve initialized browser audio'); } };
  t.context = context;
  t.node = { port: { postMessage: message => audioMessages.push(message) } };
  t.worker = { postMessage: message => messages.push(message), terminate() {} };
  t.connected = true;
  t.addEventListener('status', event => statuses.push(event.detail));
  await t.stop();
  assert.deepEqual(messages, [{ type: 'command', command: { type: 'stop' } }, { type: 'close' }]);
  assert.deepEqual(audioMessages, [{ type: 'reset' }]);
  assert.equal(t.worker, null); assert.equal(t.connected, false); assert.equal(t.context, context);
  assert.deepEqual(statuses, [{ running: false, released: true }]);
});
test('idle and unrelated status cannot acknowledge Start before the matching native reset', async () => {
  const t = new ReceiverTransport(), sent = deferred();
  t.startupTimeoutMs = 1000;
  t.prepareAudio = async () => {};
  t.connect = async () => { t.connected = true; };
  t.attachAudio = () => {};
  t.send = command => sent.resolve(command);
  let settled = false;
  const pending = t.start({ frequency: 162550000, mode: 'FM' }).then(result => { settled = true; return result; });
  await sent.promise;
  t.emit('status', { running: false, reset: true, frequency: 162550000, mode: 'FM' });
  t.emit('status', { running: true, frequency: 162550000, mode: 'FM' });
  t.emit('status', { running: true, reset: true, frequency: 100100000, mode: 'WFM' });
  await Promise.resolve();
  assert.equal(settled, false);
  t.emit('status', { running: true, reset: true, frequency: 162550000, mode: 'FM' });
  assert.equal(await pending, true);
});
test('unacknowledged native Start times out and releases receiver ownership', async () => {
  const t = new ReceiverTransport(), messages = [];
  t.startupTimeoutMs = 20;
  t.prepareAudio = async () => {};
  t.connect = async () => {
    t.worker = { postMessage: message => messages.push(message), terminate() {} };
    t.connected = true;
  };
  t.attachAudio = () => {};
  await assert.rejects(t.start({ frequency: 162550000, mode: 'FM' }), /receiver did not start in time/i);
  assert.deepEqual(messages.map(message => message.type), ['command', 'close']);
  assert.equal(t.connected, false); assert.equal(t.worker, null); assert.equal(t.cancelStartWait, null);
});
test('failed Start submission clears its acknowledgement listener and releases ownership', async () => {
  const t = new ReceiverTransport(), messages = [];
  t.startupTimeoutMs = 20;
  t.prepareAudio = async () => {};
  t.connect = async () => {
    t.worker = { postMessage: message => messages.push(message), terminate() {} };
    t.connected = true;
  };
  t.attachAudio = () => {};
  t.send = () => { throw new Error('Connection closed during command submission'); };
  await assert.rejects(t.start({ frequency: 162550000, mode: 'FM' }), /Connection closed during command submission/);
  assert.deepEqual(messages, [{ type: 'close' }]);
  assert.equal(t.cancelStartWait, null); assert.equal(t.connected, false); assert.equal(t.worker, null);
});
test('Stop during native acknowledgement cancels Start without a later timeout', async () => {
  const t = new ReceiverTransport(), sent = deferred();
  t.startupTimeoutMs = 20;
  t.prepareAudio = async () => {};
  t.connect = async () => { t.connected = true; };
  t.attachAudio = () => {};
  t.send = command => { if (command.type === 'start') sent.resolve(); };
  const pending = t.start({ frequency: 162550000, mode: 'FM' });
  await sent.promise; await t.stop();
  assert.equal(await pending, false); assert.equal(t.cancelStartWait, null);
  assert.equal(t.connected, false);
});
test('closing during session fetch invalidates worker creation and is volume-safe', async () => {
  const original = globalThis.fetch, response = deferred();
  globalThis.fetch = () => response.promise;
  try {
    const t = new ReceiverTransport();
    t.gain = {}; t.context = { close: async () => {} };
    const opening = t.connect(); t.close();
    assert.doesNotThrow(() => t.setVolume(0.3));
    response.resolve({ ok: true, json: async () => ({ token: 'test' }) });
    await assert.rejects(opening, { name: 'AbortError' });
    assert.equal(t.worker, null); assert.equal(t.connected, false);
  } finally { globalThis.fetch = original; }
});
test('failed audio module initialization cleans up so retry can recover', async () => {
  const originalContext = globalThis.AudioContext, originalNode = globalThis.AudioWorkletNode;
  let closed = 0;
  globalThis.AudioContext = class {
    constructor() { this.audioWorklet = { addModule: async () => { throw new Error('module failed'); } }; }
    async resume() {} async close() { closed++; }
  };
  globalThis.AudioWorkletNode = class {};
  try {
    const t = new ReceiverTransport();
    await assert.rejects(t.prepareAudio(), /module failed/);
    assert.equal(t.context, null); assert.equal(t.audioReady, null); assert.equal(closed, 1);
    await assert.rejects(t.prepareAudio(), /module failed/); assert.equal(closed, 2);
  } finally { globalThis.AudioContext = originalContext; globalThis.AudioWorkletNode = originalNode; }
});
for (const phase of ['resume', 'module']) {
  test(`a stalled audio ${phase} fails within a deadline, cleans up, and allows a fresh retry`, async () => {
    const blocked = deferred();
    const fixture = audioFixture({ [phase]: (_, attempt) => attempt === 1 ? blocked.promise : Promise.resolve() });
    await withGlobals(fixture.globals, async () => {
      const t = new ReceiverTransport(); t.startupTimeoutMs = 20;
      await assert.rejects(t.prepareAudio(), /Browser audio could not start.*sound is allowed/i);
      assert.equal(t.context, null); assert.equal(t.audioReady, null); assert.equal(t.node, null); assert.equal(t.gain, null);
      assert.equal(fixture.contexts[0].closed, 1);
      await t.prepareAudio();
      const recovered = t.context;
      assert.equal(recovered, fixture.contexts[1]); assert.equal(recovered.state, 'running');
      blocked.resolve();
      await Promise.resolve(); await Promise.resolve();
      assert.equal(t.context, recovered); assert.equal(recovered.closed, 0);
      t.close();
    });
  });
}
test('timed-out audio authorization cannot start hardware after its promise eventually resolves', async () => {
  const blocked = deferred();
  const fixture = audioFixture({ resume: () => blocked.promise });
  await withGlobals(fixture.globals, async () => {
    const t = new ReceiverTransport(); t.startupTimeoutMs = 20;
    t.connect = async () => assert.fail('Hardware must not be claimed before browser audio starts');
    await assert.rejects(t.start({ frequency: 162550000, mode: 'FM' }), /Browser audio could not start/);
    blocked.resolve();
    await Promise.resolve(); await Promise.resolve();
    assert.equal(t.connected, false); assert.equal(t.worker, null); assert.equal(t.context, null);
  });
});
test('stream worker preserves the useful rejection reason and code through socket close', () => {
  let socket;
  const events = [];
  const scope = { self: {}, WebSocket: class { static OPEN = 1; constructor() { socket = this; } },
    postMessage: event => events.push(event), DataView, JSON, Math };
  const source = readFileSync(new URL('../../web/public/stream-worker.js', import.meta.url), 'utf8').replaceAll('import.meta.url', "'http://localhost/stream-worker.js'");
  vm.runInNewContext(source, scope);
  scope.self.onmessage({ data: { type: 'connect', url: 'ws://localhost' } });
  const message = 'The receiver is in use in another browser tab. Stop it there, then press Start here.';
  socket.onmessage({ data: JSON.stringify({ type: 'error', code: 'receiver_busy', message }) });
  socket.onerror();
  socket.onclose({ reason: '' });
  assert.equal(events.at(-1).type, 'disconnected');
  assert.equal(events.at(-1).message, message); assert.equal(events.at(-1).code, 'receiver_busy');
  assert.ok(events.every(event => event.message === message));
});
test('suspended audio port admits only eight packets, then resets before resuming live data', () => {
  let socket;
  const port = { messages: [], postMessage(value) { this.messages.push(value); }, close() {} };
  const scope = { self: {}, WebSocket: class { static OPEN = 1; constructor() { socket = this; } },
    postMessage() {}, DataView, JSON, Math };
  const source = readFileSync(new URL('../../web/public/stream-worker.js', import.meta.url), 'utf8').replaceAll('import.meta.url', "'http://localhost/stream-worker.js'");
  vm.runInNewContext(source, scope);
  scope.self.onmessage({ data: { type: 'connect', url: 'ws://localhost' } });
  scope.self.onmessage({ data: { type: 'audio-port', port } });
  function packet() { const buffer = new ArrayBuffer(2052); new DataView(buffer).setUint32(0, 1, true); socket.onmessage({ data: buffer }); }
  for (let i = 0; i < 1000; i++) packet();
  assert.equal(port.messages.length, 8);
  port.onmessage({ data: { type: 'accepted' } }); packet();
  assert.equal(port.messages[8].type, 'reset'); assert.equal(port.messages[9].type, 'pcm');
});
