@echo off
cd /d "%~dp0.."
where py >nul 2>nul
if %errorlevel% equ 0 (
  py -3 scripts\run-web.py %*
) else (
  python scripts\run-web.py %*
)
if errorlevel 1 pause
