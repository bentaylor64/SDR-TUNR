# Local receiver bridge

The browser interface uses the same native C receiver and DSP as Tuner 1.14.0.
This small Python 3.9+ standard-library process opens **RTL-SDR USB receivers**
through librtlsdr. It binds only to `127.0.0.1`, serves the browser files, and sends
48 kHz mono audio and optional spectrum snapshots over a local WebSocket.
There are no pip packages, cloud audio services, or CDN dependencies.

The USB radio is not a serial port. Web Serial cannot operate an RTL-SDR. Browsers
also cannot directly load arbitrary native USB drivers. This local bridge is the
driver boundary; a web permission prompt is not a replacement for librtlsdr or
the operating system's USB driver. Its supported receiver family is RTL-SDR,
including compatible NESDR Mini hardware, rather than every SDR chipset.

## Run

From the project directory:

```sh
python3 scripts/build-web-core.py
python3 web/bridge/server.py --open
```

The default address is `http://127.0.0.1:8780`. Use `--port 8781` for another port.
Close other programs using the SDR, connect it, and refresh the device list.
Stopping playback or closing the owning browser tab closes the receiver.
Only one browser tab may own the stream at a time. Stop the bridge with Ctrl+C.

`python3 web/bridge/server.py --demo --open` explicitly enables a generated
700 Hz audio tone and IQ test signal. The API marks the entire session as demo.
This tests the browser path without representing hardware reception. Missing
drivers and missing devices never silently activate demo mode.

## Driver and build prerequisites

- **macOS:** Python 3.9+, Xcode Command Line Tools, and a local `rtl-sdr`
  installation from MacPorts or Homebrew. Existing default install paths are
  retained. The build produces `native/libradiocore.dylib`.
- **Linux:** Python 3.9+, a C compiler with pthreads, and librtlsdr (`rtl-sdr` / the
  distribution's librtlsdr package). Configure the receiver's udev permissions
  and resolve a conflicting DVB kernel driver according to your distribution's
  RTL-SDR setup. Run as your normal user. Output: `native/libradiocore.so`.
- **Windows:** 64-bit Python 3.9+ and a matching 64-bit librtlsdr distribution,
  including its libusb dependency. Use an MSYS2 **UCRT64 MinGW-w64 GCC** compiler
  to build with `py scripts\build-web-core.py --cc C:\msys64\ucrt64\bin\gcc.exe`.
  Output: `native\radiocore.dll`; winpthreads and GCC runtime are statically linked.
  Put `rtlsdr.dll` (or `librtlsdr.dll`) and its required DLLs in `web\bridge\native`,
  or set `RTLSDR_LIBRARY` to the driver's absolute path. If the receiver's driver
  needs changing, use the trusted RTL-SDR/Zadig instructions for **that receiver's
  Bulk-In Interface 0**, with WinUSB. Do not change unrelated device drivers.
  Launch with `py web\bridge\server.py --open`.

`RTLSDR_LIBRARY` must name an absolute driver-library path when used. An invalid
override is reported instead of loading another installation. Windows DLL lookup
does not search the current working directory; the bridge adds only its native
library directory and an explicitly configured driver's directory.

Windows and Linux portability are implemented, but require validation with the
target compiler, matching driver build, and physical receiver before a release
can claim support verified on those systems.

## Latency and isolation

Native USB capture and DSP remain outside the browser. One receiver worker owns
all device control and DSP calls; capture stays on the existing native callback
thread. Audio is approximately 10.7 ms per packet. The outbound queue holds at
most six audio packets and drops the oldest when a consumer falls behind.
Spectrum is one latest snapshot, capped at 10 updates/second. A stalled socket
is disconnected when a send cannot drain within 500 ms. These bounds limit
backlog; they are not a measured end-to-end latency guarantee.

Tuning flushes queued audio/IQ and emits a reset boundary. Fine tuning within
600 kHz of the active capture center uses the existing stationary-window DSP
path; larger changes retune the hardware. A short settling period discards
samples before new-channel delivery. Squelch gates audio using DSP channel
power in dBFS, not calibrated RF dBm. It preserves the desktop's 3 dB hysteresis,
150 ms release hang, and gradual sample envelope to prevent block-edge clicks.

HTTP requires an exact loopback Host and rejects foreign Origin and cross-site
requests. The WebSocket additionally requires a same-origin browser Origin and
a random process-session token obtained from `/api/session`. Static files are
confined to `web/public`; there is no CORS access or LAN binding option. Content
Security Policy permits local scripts/workers and the ZIP lookup endpoint
`https://api.zippopotam.us` only. The local process is intended for a single-user
desktop; any already-authorized local process can access localhost.

## Wire contract

- `GET /api/session`: `token`, `version`, `demo`, `audioRate`, `sampleRate`, and
  `receiverBusy` (true while another browser owns or is releasing the receiver).
- `GET /api/devices`: `driverAvailable`, `devices: [{index, name}]`, `demo`, and
  `error` if core/driver setup is unavailable.
- `GET /stream?token=...`: authenticated WebSocket; one owner at a time.
  An authenticated second client receives an error with `code: "receiver_busy"`
  and WebSocket close code 1013. It never changes the active owner's session.
- JSON commands: `start`/`tune` with `frequency` (integer Hz), `mode`
  (`FM`, `WFM`, `AM`, `USB`, `LSB`, `CW`), `device`, `ppm`, `gain` (tenths of dB;
  `-1` means auto), `squelch` (integer dBFS). Start requires frequency; omitted
  fields retain existing settings. `stop`, `spectrum` with boolean `enabled`,
  and `squelch` with integer `value` are also supported.
- JSON status: `type: "status"`, `running`, `frequency`, `mode`, `center`,
  `power`, `sampleRate`, `driverAvailable`, `demo`, `dspMs`,
  `captureDroppedBytes`, `droppedAudioBlocks`. Meter updates are capped at 10 Hz.
  Start/tune/stop sends `reset: true` before subsequent audio. Errors include
  a stopped status and `{type: "error", message}`.
- Audio binary: little-endian uint32 `1`, followed by 48 kHz mono float32 samples.
- IQ binary: little-endian uint32 `2`, uint32 capture center in Hz, uint32 sample
  rate, followed by 4096 unsigned interleaved I/Q samples (8192 bytes).

## Verification

```sh
python3 -B -m unittest discover -s web/bridge -v
bash scripts/test-capture.sh
```

Tests cover real loopback HTTP/WebSocket connections, origin/token/owner guards,
input validation, bounded queues, retune ordering, audio/IQ formats, and receiver
stop on disconnect. Existing C capture tests cover asynchronous capture and
retune behavior with a simulated USB adapter; neither suite claims RF reception.
