"""Run: python3 -B -m unittest discover -s web/bridge -v"""
import asyncio
import base64
import io
import json
from pathlib import Path
import struct
import tempfile
import threading
import time
import unittest
from unittest import mock

from server import Bridge, DemoCore, NativeCore, Outbox, ReceiverWorker, SAMPLE_RATE, Session, SquelchGate, validate_command


def client_frame(payload, opcode=1):
    if isinstance(payload, dict):
        payload = json.dumps(payload).encode()
    mask = b"test"
    prefix = bytes((0x80 | opcode, 0x80 | len(payload))) if len(payload) < 126 else bytes((0x80 | opcode, 0x80 | 126)) + struct.pack("!H", len(payload))
    return prefix + mask + bytes(byte ^ mask[i % 4] for i, byte in enumerate(payload))


async def server_frame(reader):
    first, second = await reader.readexactly(2)
    size = second & 127
    if size == 126:
        size = struct.unpack("!H", await reader.readexactly(2))[0]
    elif size == 127:
        size = struct.unpack("!Q", await reader.readexactly(8))[0]
    return first & 15, await reader.readexactly(size)


class TrackingCore(DemoCore):
    def __init__(self):
        super().__init__()
        self.calls = []
        self.opened = False

    def record(self, name):
        self.calls.append((name, threading.get_ident()))

    def devices(self):
        self.record("devices")
        return super().devices()

    def open(self, settings):
        self.record("open")
        self.opened = True
        super().open(settings)

    def tune(self, settings):
        self.record("tune")
        super().tune(settings)

    def read(self, spectrum):
        self.record("read")
        return super().read(spectrum)

    def close(self):
        self.record("close")
        self.opened = False
        super().close()


class ValidationTests(unittest.TestCase):
    def test_valid_modes_and_edge_frequencies(self):
        for mode in ("FM", "WFM", "AM", "USB", "LSB", "CW"):
            for frequency in (25_000_000, 1_750_000_000):
                self.assertEqual(validate_command({"type": "start", "frequency": frequency, "mode": mode})["mode"], mode)

    def test_untrusted_values_rejected(self):
        invalid = [None, [], {}, {"type": "exec"}, {"type": "start"}, {"type": "start", "frequency": True},
                   {"type": "start", "frequency": 24_999_999}, {"type": "tune", "frequency": 1_750_000_001},
                   {"type": "tune", "frequency": 100.1}, {"type": "tune", "ppm": 201}, {"type": "tune", "device": -1},
                   {"type": "tune", "mode": []}, {"type": "tune", "gain": 501}, {"type": "tune", "extra": 1},
                   {"type": "spectrum", "enabled": 1}, {"type": "squelch", "value": -121}, {"type": "stop", "frequency": 1}]
        for command in invalid:
            with self.subTest(command=command), self.assertRaises(ValueError):
                validate_command(command)

    def test_missing_core_is_explicit(self):
        core = NativeCore(Path(tempfile.gettempdir()) / "tuner-test-nonexistent-native-library")
        self.assertFalse(core.driver_available)
        self.assertEqual(core.devices()["devices"], [])
        self.assertIn("Receiver core unavailable", core.devices()["error"])
        with self.assertRaises(RuntimeError):
            core.open({"device": 0})

    def test_squelch_hysteresis_hang_and_envelope(self):
        gate = SquelchGate()
        audio = struct.pack("<480f", *([1.0] * 480))
        silent = gate.process(audio, -80, -60)
        self.assertEqual(silent, bytes(len(audio)))
        rising = struct.unpack("<480f", gate.process(audio, -50, -60))
        self.assertAlmostEqual(rising[0], 0.02, places=5)
        self.assertGreater(rising[-1], 0.99)
        gate.process(audio, -62, -60)
        self.assertTrue(gate.open, "hysteresis keeps the gate open within 3 dB")
        for _ in range(14):
            gate.process(audio, -70, -60)
        self.assertTrue(gate.open, "short gaps retain the 150 ms hang")
        falling = struct.unpack("<480f", gate.process(audio, -70, -60))
        self.assertFalse(gate.open)
        self.assertGreater(falling[0], 0.97)
        self.assertLess(falling[-1], 0.001)


class QueueTests(unittest.IsolatedAsyncioTestCase):
    async def test_bounded_audio_keeps_latest_and_single_iq(self):
        out = Outbox(asyncio.get_running_loop())
        for number in range(100):
            out.put("audio", number)
            out.put("iq", number)
        with out.lock:
            items = list(out.items)
        self.assertEqual([value for kind, value in items if kind == "audio"], list(range(94, 100)))
        self.assertEqual([value for kind, value in items if kind == "iq"], [99])
        self.assertEqual(out.dropped_audio, 94)

    async def test_tune_reset_discards_old_channel_and_preserves_fence(self):
        out = Outbox(asyncio.get_running_loop())
        out.put("audio", b"old")
        out.put("iq", b"old")
        out.reset({"type": "status", "reset": True})
        out.put("audio", b"new")
        out.put("status", {"type": "status", "power": -25})
        out.put("status", {"type": "status", "power": -20})
        self.assertEqual((await out.get())[0], "reset")
        self.assertEqual(await out.get(), ("audio", b"new"))
        self.assertEqual((await out.get())[1]["power"], -20)
        out.close()
        self.assertIsNone(await out.get())

    async def test_late_retune_does_not_revive_closed_outbox(self):
        out = Outbox(asyncio.get_running_loop())
        out.put("audio", b"old")
        out.close()
        out.reset({"type": "status", "reset": True})
        out.put("audio", b"late")
        self.assertIsNone(await out.get())
        self.assertFalse(out.items)

    async def test_control_burst_cannot_displace_reset_fence(self):
        out = Outbox(asyncio.get_running_loop())
        out.reset({"type": "status", "reset": True})
        for _ in range(100):
            out.put("error", {"type": "error", "message": "Invalid command"})
        out.put("audio", b"new channel")
        self.assertLessEqual(len(out.items), 16)
        self.assertEqual((await out.get())[0], "reset")

    async def test_shutdown_resolves_session_queued_before_attach(self):
        with mock.patch.object(threading.Thread, "start"):
            worker = ReceiverWorker(DemoCore())
        session = Session(asyncio.get_running_loop())
        worker.submit(session, {"type": "attach"})
        worker.shutdown.set()
        worker.run()
        self.assertTrue(session.stopped.is_set())

    async def test_default_http_port_uses_canonical_browser_origin(self):
        # A browser omits the default port when serializing an Origin.
        with mock.patch.object(threading.Thread, "start"):
            bridge = Bridge(DemoCore(), port=80)
        self.assertTrue(bridge.allowed_request({"host": "localhost", "origin": "http://localhost"}, require_origin=True))
        self.assertTrue(bridge.allowed_request({"host": "localhost:80", "origin": "http://localhost"}, require_origin=True))
        self.assertFalse(bridge.allowed_request({"host": "localhost.attacker.example", "origin": "http://localhost.attacker.example"}))


class BridgeTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.directory = tempfile.TemporaryDirectory()
        Path(self.directory.name, "index.html").write_text("<html>local receiver</html>")
        self.core = TrackingCore()
        self.bridge = Bridge(self.core, 0, self.directory.name)
        await self.bridge.start()
        self.host = f"127.0.0.1:{self.bridge.port}"
        self.connections = []

    async def asyncTearDown(self):
        for writer in self.connections:
            writer.close()
            await writer.wait_closed()
        for _ in range(100):
            if self.bridge.owner is None:
                break
            await asyncio.sleep(0.01)
        await self.bridge.close()
        self.directory.cleanup()

    async def request(self, target, headers=None, method="GET"):
        reader, writer = await asyncio.open_connection("127.0.0.1", self.bridge.port)
        entries = {"Host": self.host, **(headers or {})}
        request = f"{method} {target} HTTP/1.1\r\n" + "".join(f"{key}: {value}\r\n" for key, value in entries.items()) + "\r\n"
        writer.write(request.encode())
        await writer.drain()
        response = await reader.read()
        writer.close()
        await writer.wait_closed()
        return response

    async def websocket(self, token=None, origin=None):
        reader, writer = await asyncio.open_connection("127.0.0.1", self.bridge.port)
        self.connections.append(writer)
        token = self.bridge.token if token is None else token
        origin = f"http://{self.host}" if origin is None else origin
        writer.write((f"GET /stream?token={token} HTTP/1.1\r\nHost: {self.host}\r\nOrigin: {origin}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Version: 13\r\nSec-WebSocket-Key: {base64.b64encode(bytes(16)).decode()}\r\n\r\n").encode())
        await writer.drain()
        response = await reader.readuntil(b"\r\n\r\n")
        return reader, writer, response

    async def next_status(self, reader, predicate=lambda status: True):
        async def find():
            while True:
                kind, payload = await server_frame(reader)
                if kind == 1:
                    message = json.loads(payload)
                    if message.get("type") == "status" and predicate(message):
                        return message
        return await asyncio.wait_for(find(), 2)

    async def test_session_static_and_devices(self):
        response = await self.request("/api/session")
        headers, body = response.split(b"\r\n\r\n", 1)
        self.assertIn(b"200 OK", headers)
        self.assertIn(b"Content-Security-Policy:", headers)
        payload = json.loads(body)
        self.assertTrue(payload["demo"])
        self.assertEqual(payload["token"], self.bridge.token)
        self.assertEqual(payload["version"], "1.14.0")
        self.assertFalse(payload["receiverBusy"])
        self.assertIn(b"local receiver", await self.request("/"))
        response = await self.request("/api/devices")
        payload = json.loads(response.split(b"\r\n\r\n", 1)[1])
        self.assertFalse(payload["driverAvailable"])
        self.assertEqual(payload["devices"][0]["index"], 0)

    async def test_origin_host_and_path_guards(self):
        for headers in ({"Host": "attacker.example"}, {"Origin": "https://attacker.example"}, {"Sec-Fetch-Site": "cross-site"}, {"Origin": "null"}, {"Origin": f"http://localhost:{self.bridge.port}"}):
            self.assertIn(b"403 Forbidden", await self.request("/api/session", headers))
        self.assertIn(b"404 Not Found", await self.request("/../../bridge/server.py"))
        self.assertIn(b"404 Not Found", await self.request("/%2e%2e/bridge/server.py"))
        self.assertIn(b"405 Method Not Allowed", await self.request("/api/session", method="POST"))

    async def test_websocket_requires_token_and_origin_and_single_owner(self):
        _, _, response = await self.websocket(token="bad")
        self.assertIn(b"403 Forbidden", response)
        _, _, response = await self.websocket(origin="https://attacker.example")
        self.assertIn(b"403 Forbidden", response)
        first_reader, first_writer, response = await self.websocket()
        self.assertIn(b"101 Switching", response)
        await self.next_status(first_reader)
        original_owner = self.bridge.owner
        response = await self.request("/api/session")
        self.assertTrue(json.loads(response.split(b"\r\n\r\n", 1)[1])["receiverBusy"])
        busy_reader, _, response = await self.websocket()
        self.assertIn(b"101 Switching", response)
        opcode, payload = await asyncio.wait_for(server_frame(busy_reader), 2)
        self.assertEqual(opcode, 1)
        message = json.loads(payload)
        self.assertEqual(message["type"], "error")
        self.assertEqual(message["code"], "receiver_busy")
        self.assertIn("another browser tab", message["message"])
        opcode, payload = await asyncio.wait_for(server_frame(busy_reader), 2)
        self.assertEqual(opcode, 8)
        self.assertEqual(struct.unpack_from("!H", payload)[0], 1013)
        self.assertIs(self.bridge.owner, original_owner)
        # Refusing the second browser leaves the original controller usable.
        first_writer.write(client_frame({"type": "start", "frequency": 100_100_000}))
        await self.next_status(first_reader, lambda status: status["running"])
        first_writer.close()
        await first_writer.wait_closed()
        for _ in range(100):
            if self.bridge.owner is None:
                break
            await asyncio.sleep(0.01)
        response = await self.request("/api/session")
        self.assertFalse(json.loads(response.split(b"\r\n\r\n", 1)[1])["receiverBusy"])
        new_reader, _, response = await self.websocket()
        self.assertIn(b"101 Switching", response)
        await self.next_status(new_reader, lambda status: not status["running"])

    async def test_denial_diagnostics_omit_queries_tokens_and_escape_controls(self):
        output = io.StringIO()
        with mock.patch("server.sys.stderr", output):
            await self.request("/api/session?token=private-query", {"Origin": "https://attacker.example"})
            await self.websocket(token="private-websocket-query")
            self.bridge.diagnose("test", {"host": "localhost", "origin": "https://example.invalid/?token=private-origin-query",
                                          "sec-fetch-site": "cross-site\nINJECT"}, "/" + self.bridge.token + "?other=private-path-query")
        text = output.getvalue()
        self.assertNotIn("private-", text)
        self.assertNotIn(self.bridge.token, text)
        lines = text.splitlines()
        self.assertEqual(len(lines), 3)
        records = [json.loads(line.removeprefix("Tuner bridge ")) for line in lines]
        self.assertEqual(records[0]["path"], "/api/session")
        self.assertEqual(records[0]["origin"], "https://attacker.example")
        self.assertEqual(records[1]["event"], "websocket_denied_auth")
        self.assertEqual(records[1]["path"], "/stream")
        self.assertEqual(records[2]["path"], "/[redacted]")
        self.assertIn("\\n", lines[2])

    async def test_audio_iq_tune_stop_and_disconnect_serialize_native_calls(self):
        reader, writer, response = await self.websocket()
        self.assertIn(b"101 Switching", response)
        await self.next_status(reader, lambda s: not s["running"])
        writer.write(client_frame({"type": "start", "frequency": 100_100_000, "mode": "WFM"}))
        status = await self.next_status(reader, lambda s: s["running"])
        self.assertTrue(status["reset"])
        self.assertTrue(status["demo"])
        center = status["center"]
        packets = {}
        while len(packets) < 2:
            kind, payload = await asyncio.wait_for(server_frame(reader), 2)
            if kind == 2:
                packets[struct.unpack_from("<I", payload)[0]] = payload
        self.assertEqual(len(packets[1]), 4 + 512 * 4)
        self.assertEqual(len(packets[2]), 12 + 8192)
        self.assertEqual(struct.unpack_from("<II", packets[2], 4), (center, SAMPLE_RATE))
        writer.write(client_frame({"type": "tune", "frequency": 100_125_000}))
        status = await self.next_status(reader, lambda s: s["frequency"] == 100_125_000 and s.get("reset"))
        self.assertEqual(status["center"], center, "fine tuning must keep the capture center stationary")
        writer.write(client_frame({"type": "stop"}))
        status = await self.next_status(reader, lambda s: not s["running"])
        self.assertTrue(status["reset"])
        self.assertFalse(self.core.opened)
        writer.write(client_frame({"type": "start", "frequency": 162_550_000, "mode": "FM"}))
        await self.next_status(reader, lambda s: s["running"])
        self.assertTrue(self.core.opened)
        writer.close()
        await writer.wait_closed()
        for _ in range(100):
            if self.bridge.owner is None:
                break
            await asyncio.sleep(0.01)
        self.assertIsNone(self.bridge.owner)
        self.assertFalse(self.core.opened)
        self.assertEqual({identity for _, identity in self.core.calls}, {self.bridge.worker.thread.ident})

    async def test_invalid_commands_do_not_start_receiver(self):
        reader, writer, _ = await self.websocket()
        await self.next_status(reader)
        writer.write(client_frame({"type": "start", "frequency": 0}))
        opcode, payload = await asyncio.wait_for(server_frame(reader), 2)
        self.assertEqual(opcode, 1)
        self.assertEqual(json.loads(payload)["type"], "error")
        self.assertFalse(self.core.opened)

    async def test_unmasked_frame_disconnects_and_stops_receiver(self):
        reader, writer, _ = await self.websocket()
        await self.next_status(reader)
        writer.write(client_frame({"type": "start", "frequency": 100_100_000}))
        await self.next_status(reader, lambda s: s["running"])
        writer.write(b"\x81\x02{}")
        await writer.drain()
        await asyncio.wait_for(reader.read(), 2)
        for _ in range(100):
            if self.bridge.owner is None:
                break
            await asyncio.sleep(0.01)
        self.assertFalse(self.core.opened)

    async def test_socket_aborts_before_slow_native_close_and_retains_ownership(self):
        reader, writer, _ = await self.websocket()
        await self.next_status(reader)
        writer.write(client_frame({"type": "start", "frequency": 100_100_000}))
        await self.next_status(reader, lambda s: s["running"])
        release = threading.Event()
        original_close = self.core.close

        def slow_close():
            if self.core.opened:
                release.wait(2)
            original_close()

        self.core.close = slow_close
        try:
            writer.write(b"\x81\x02{}")
            await writer.drain()
            await asyncio.wait_for(reader.read(), 0.5)
            self.assertTrue(self.core.opened)
            self.assertIsNotNone(self.bridge.owner)
            response = await self.request("/api/session")
            self.assertTrue(json.loads(response.split(b"\r\n\r\n", 1)[1])["receiverBusy"])
            original_owner = self.bridge.owner
            busy_reader, _, response = await self.websocket()
            self.assertIn(b"101 Switching", response)
            _, payload = await asyncio.wait_for(server_frame(busy_reader), 2)
            self.assertEqual(json.loads(payload)["code"], "receiver_busy")
            self.assertIs(self.bridge.owner, original_owner)
        finally:
            release.set()
        for _ in range(100):
            if self.bridge.owner is None:
                break
            await asyncio.sleep(0.01)
        self.assertIsNone(self.bridge.owner)
        self.assertFalse(self.core.opened)


if __name__ == "__main__":
    unittest.main()
