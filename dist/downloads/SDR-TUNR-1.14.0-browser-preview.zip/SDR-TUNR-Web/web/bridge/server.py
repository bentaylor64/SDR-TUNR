#!/usr/bin/env python3
"""Local browser receiver bridge. Python standard library only; never LAN-bound."""
from __future__ import annotations

import argparse
import array
import asyncio
import base64
from collections import deque
import concurrent.futures
import ctypes
import hashlib
import hmac
import json
import math
import mimetypes
import os
from pathlib import Path
import queue
import secrets
import socket
import struct
import sys
import threading
import time
import webbrowser
from urllib.parse import parse_qs, unquote, urlsplit

VERSION = "1.14.0"
SAMPLE_RATE = 1_536_000
AUDIO_RATE = 48_000
MODES = {"FM": 0, "WFM": 1, "AM": 2, "USB": 3, "LSB": 4, "CW": 5}
DEFAULTS = {"frequency": 100_100_000, "mode": "WFM", "device": 0, "ppm": 0, "gain": 300, "squelch": -60}
ROOT = Path(__file__).resolve().parents[2]
PUBLIC = ROOT / "web" / "public"
MAX_COMMAND = 4096
WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"


def validate_command(value):
    if not isinstance(value, dict) or not isinstance(value.get("type"), str):
        raise ValueError("A command must be a JSON object with a type.")
    kind = value["type"]
    if kind in ("start", "tune"):
        allowed = set(DEFAULTS) | {"type"}
        if set(value) - allowed:
            raise ValueError("Unknown receiver setting.")
        if kind == "start" and "frequency" not in value:
            raise ValueError("Start requires frequency in integer Hz.")
        limits = {"frequency": (25_000_000, 1_750_000_000), "device": (0, 255), "ppm": (-200, 200), "gain": (-1, 500), "squelch": (-120, 0)}
        for key, (low, high) in limits.items():
            if key in value and (type(value[key]) is not int or not low <= value[key] <= high):
                raise ValueError(f"{key} must be an integer between {low} and {high}.")
        if "mode" in value and (not isinstance(value["mode"], str) or value["mode"] not in MODES):
            raise ValueError("Mode must be FM, WFM, AM, USB, LSB or CW.")
    elif kind == "stop":
        if set(value) != {"type"}:
            raise ValueError("Stop has no settings.")
    elif kind == "spectrum":
        if set(value) != {"type", "enabled"} or type(value["enabled"]) is not bool:
            raise ValueError("Spectrum requires an enabled boolean.")
    elif kind == "squelch":
        if set(value) != {"type", "value"} or type(value["value"]) is not int or not -120 <= value["value"] <= 0:
            raise ValueError("Squelch must be an integer between -120 and 0.")
    else:
        raise ValueError("Unknown receiver command.")
    return value


class IQView(ctypes.Structure):
    _fields_ = [("bytes", ctypes.POINTER(ctypes.c_uint8)), ("byte_count", ctypes.c_int), ("center_frequency", ctypes.c_uint32), ("sample_rate", ctypes.c_uint32)]


class ReadMetrics(ctypes.Structure):
    _fields_ = [("input_wait_milliseconds", ctypes.c_double), ("dsp_milliseconds", ctypes.c_double), ("capture_dropped_bytes", ctypes.c_uint64), ("capture_high_water_blocks", ctypes.c_int), ("sample_rate", ctypes.c_uint32)]


class NativeCore:
    demo = False

    def __init__(self, path=None):
        self.lib = None
        self.handle = None
        self.center = None
        self.error = None
        self._dll_dirs = []
        self.audio = (ctypes.c_float * 512)()
        name = "radiocore.dll" if os.name == "nt" else "libradiocore.dylib" if sys.platform == "darwin" else "libradiocore.so"
        library = Path(path) if path else Path(__file__).parent / "native" / name
        override = os.environ.get("RTLSDR_LIBRARY")
        if override and not Path(override).is_absolute():
            self.error = "RTLSDR_LIBRARY must be an absolute path to your local driver library."
            return
        try:
            if os.name == "nt":
                directories = {library.resolve().parent}
                if override:
                    directories.add(Path(override).parent)
                self._dll_dirs = [os.add_dll_directory(str(directory)) for directory in directories]
            self.lib = ctypes.CDLL(str(library.resolve()))
            signatures = {
                "radio_driver_available": ([], ctypes.c_int), "radio_device_count": ([], ctypes.c_int),
                "radio_device_name": ([ctypes.c_int, ctypes.c_char_p, ctypes.c_int], None),
                "radio_open": ([ctypes.c_int, ctypes.c_char_p, ctypes.c_int], ctypes.c_void_p),
                "radio_close": ([ctypes.c_void_p], None),
                "radio_tune": ([ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int, ctypes.c_int, ctypes.c_int], ctypes.c_int),
                "radio_tune_at_center": ([ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_int, ctypes.c_int, ctypes.c_int], ctypes.c_int),
                "radio_tuning_center": ([ctypes.c_uint32], ctypes.c_uint32),
                "radio_read": ([ctypes.c_void_p, ctypes.POINTER(ctypes.c_float), ctypes.c_int, ctypes.POINTER(ctypes.c_float)], ctypes.c_int),
                "radio_get_iq_view": ([ctypes.c_void_p], IQView), "radio_get_read_metrics": ([ctypes.c_void_p], ReadMetrics),
            }
            for function, (args, result) in signatures.items():
                getattr(self.lib, function).argtypes = args
                getattr(self.lib, function).restype = result
            if not self.lib.radio_driver_available():
                self.error = "RTL-SDR driver not found. Install librtlsdr and the USB driver for your receiver; see the browser setup guide."
        except (OSError, AttributeError) as error:
            self.lib = None
            self.error = f"Receiver core unavailable. Run python3 scripts/build-web-core.py. ({error})"

    @property
    def driver_available(self):
        return self.lib is not None and self.error is None

    def devices(self):
        result = {"driverAvailable": self.driver_available, "devices": [], "demo": False}
        if self.error:
            result["error"] = self.error
        if self.driver_available:
            for index in range(self.lib.radio_device_count()):
                name = ctypes.create_string_buffer(512)
                self.lib.radio_device_name(index, name, len(name))
                result["devices"].append({"index": index, "name": name.value.decode("utf-8", "replace")})
        return result

    def open(self, settings):
        if not self.driver_available:
            raise RuntimeError(self.error)
        error = ctypes.create_string_buffer(512)
        self.handle = self.lib.radio_open(settings["device"], error, len(error))
        if not self.handle:
            raise RuntimeError(error.value.decode("utf-8", "replace") or "Could not open receiver.")
        self.tune(settings)

    def tune(self, settings):
        frequency = settings["frequency"]
        center = self.center
        if center is None or abs(center - frequency) > 600_000:
            center = self.lib.radio_tuning_center(frequency)
        result = self.lib.radio_tune_at_center(self.handle, frequency, center, MODES[settings["mode"]], settings["ppm"], settings["gain"])
        if result != 0:
            raise RuntimeError(f"Receiver could not apply tuning settings ({result}).")
        self.center = center

    def read(self, spectrum):
        power = ctypes.c_float(-120)
        frames = self.lib.radio_read(self.handle, self.audio, len(self.audio), ctypes.byref(power))
        if frames < 0:
            raise RuntimeError("Receiver stopped delivering samples. Check the USB connection and reconnect.")
        if frames == 0:
            return None
        audio = ctypes.string_at(self.audio, frames * 4)
        if sys.byteorder != "little":
            values = array.array("f", audio)
            values.byteswap()
            audio = values.tobytes()
        iq = None
        if spectrum:
            view = self.lib.radio_get_iq_view(self.handle)
            if view.byte_count >= 8192:
                iq = struct.pack("<III", 2, view.center_frequency, view.sample_rate) + ctypes.string_at(view.bytes, 8192)
        metrics = self.lib.radio_get_read_metrics(self.handle)
        return audio, float(power.value), iq, {"dspMs": round(metrics.dsp_milliseconds, 3), "captureDroppedBytes": metrics.capture_dropped_bytes}

    def close(self):
        if self.handle:
            self.lib.radio_close(self.handle)
            self.handle = None
        self.center = None


class DemoCore:
    """Explicit transport test signal; does not discover hardware or emulate RF."""
    demo = True
    driver_available = False
    error = None

    def __init__(self):
        self.settings = DEFAULTS.copy()
        self.frames = 0
        self.next_read = 0
        self.center = None

    def devices(self):
        return {"driverAvailable": False, "devices": [{"index": 0, "name": "Demonstration signal — no USB receiver"}], "demo": True}

    def open(self, settings):
        self.tune(settings)

    def tune(self, settings):
        if settings["device"] != 0:
            raise RuntimeError("The demonstration signal has device index 0.")
        self.settings = settings.copy()
        if self.center is None or abs(self.center - settings["frequency"]) > 600_000:
            self.center = tuning_center(settings["frequency"])
        self.next_read = time.monotonic()

    def read(self, spectrum):
        delay = self.next_read - time.monotonic()
        if delay > 0:
            time.sleep(delay)
        self.next_read = max(self.next_read + 512 / AUDIO_RATE, time.monotonic())
        audio = struct.pack("<512f", *(0.08 * math.sin(2 * math.pi * 700 * (self.frames + i) / AUDIO_RATE) for i in range(512)))
        self.frames += 512
        iq = None
        if spectrum:
            center = self.center
            offset = self.settings["frequency"] - center
            samples = bytearray(8192)
            for i in range(4096):
                phase = 2 * math.pi * offset * i / SAMPLE_RATE
                samples[i * 2] = int(127.5 + 45 * math.cos(phase))
                samples[i * 2 + 1] = int(127.5 + 45 * math.sin(phase))
            iq = struct.pack("<III", 2, center, SAMPLE_RATE) + samples
        return audio, -18.0, iq, {"dspMs": 0, "captureDroppedBytes": 0}

    def close(self):
        self.center = None


def tuning_center(frequency):
    return frequency + 384_000 if frequency <= 1_750_000_000 - 384_000 else frequency - 384_000


class Outbox:
    """At most six audio blocks, one IQ snapshot, and bounded control events.

    Only a transition from empty schedules an event-loop callback, so a stalled
    browser/event loop cannot build an unbounded cross-thread callback backlog.
    """
    def __init__(self, loop):
        self.loop = loop
        self.ready = asyncio.Event()
        self.lock = threading.Lock()
        self.items = deque()
        self.dropped_audio = 0
        self.closed = False

    def put(self, kind, payload):
        with self.lock:
            if self.closed:
                return
            was_empty = not self.items
            if kind == "audio":
                audio_count = sum(item[0] == "audio" for item in self.items)
                if audio_count >= 6:
                    for item in self.items:
                        if item[0] == "audio":
                            self.items.remove(item)
                            self.dropped_audio += 1
                            break
            elif kind in ("iq", "status"):
                # Preserve a reset status as the ordering fence for following
                # packets even when subsequent meter statuses are coalesced.
                self.items = deque(item for item in self.items if item[0] != kind)
            if len(self.items) >= 16:
                # Even a burst of invalid commands must not displace the reset
                # fence and let new-channel audio follow an old worklet buffer.
                for item in self.items:
                    if item[0] != "reset":
                        self.items.remove(item)
                        if item[0] == "audio":
                            self.dropped_audio += 1
                        break
            self.items.append((kind, payload))
        if was_empty:
            self.loop.call_soon_threadsafe(self.ready.set)

    def reset(self, status):
        with self.lock:
            if self.closed:
                return
            self.items.clear()
            self.items.append(("reset", status))
        self.loop.call_soon_threadsafe(self.ready.set)

    async def get(self):
        while True:
            with self.lock:
                if self.items:
                    return self.items.popleft()
                self.ready.clear()
                if self.closed:
                    return None
            await self.ready.wait()

    def close(self):
        with self.lock:
            self.closed = True
            self.items.clear()
        self.loop.call_soon_threadsafe(self.ready.set)


class Session:
    def __init__(self, loop):
        self.outbox = Outbox(loop)
        self.dead = threading.Event()
        self.stopped = threading.Event()


class SquelchGate:
    """Match the desktop gate: 3 dB hysteresis, 150 ms hang, smooth envelope."""
    def __init__(self):
        self.reset()

    def reset(self):
        self.open = False
        self.below_frames = 0
        self.threshold = None
        self.level = 0.0

    def process(self, audio, power, threshold):
        frames = len(audio) // 4
        if threshold != self.threshold:
            self.open = False
            self.below_frames = 0
            self.threshold = threshold
        if power >= threshold:
            self.open = True
            self.below_frames = 0
        elif self.open:
            if power >= threshold - 3:
                self.below_frames = 0
            else:
                self.below_frames += frames
                if self.below_frames >= 7200:
                    self.open = False
                    self.below_frames = 0
        target = 1.0 if self.open else 0.0
        if abs(self.level - target) < 0.00001:
            self.level = target
            return audio if self.open else bytes(len(audio))
        # Only gate transitions visit individual samples. Steady-state audio
        # stays a single byte-buffer transfer, keeping the Python path lean.
        samples = array.array("f", audio)
        if sys.byteorder != "little":
            samples.byteswap()
        for i in range(frames):
            self.level += 0.02 * (target - self.level)
            samples[i] *= self.level
        if sys.byteorder != "little":
            samples.byteswap()
        return samples.tobytes()


class ReceiverWorker:
    """All device enumeration/open/tune/read/close happens on this worker."""
    def __init__(self, core):
        self.core = core
        self.commands = queue.Queue(maxsize=32)
        self.shutdown = threading.Event()
        self.thread = threading.Thread(target=self.run, name="receiver", daemon=True)
        self.session = None
        self.settings = DEFAULTS.copy()
        self.running = False
        self.spectrum = True
        self.power = -120.0
        self.metrics = {}
        self.gate = SquelchGate()
        self.last_samples = 0.0
        self.thread.start()

    def submit(self, session, command):
        try:
            self.commands.put_nowait((session, command))
        except queue.Full:
            raise ValueError("Receiver is busy; slow down tuning commands.")

    async def devices(self):
        future = concurrent.futures.Future()
        try:
            self.commands.put_nowait((None, future))
        except queue.Full:
            return {"driverAvailable": self.core.driver_available, "devices": [], "error": "Receiver is busy. Try refreshing devices again.", "demo": self.core.demo}
        return await asyncio.wrap_future(future)

    def status(self, **extra):
        return {"type": "status", "running": self.running, "frequency": self.settings["frequency"], "mode": self.settings["mode"], "power": self.power,
                "center": self.core.center or tuning_center(self.settings["frequency"]), "sampleRate": SAMPLE_RATE, "driverAvailable": self.core.driver_available,
                "demo": self.core.demo, "droppedAudioBlocks": self.session.outbox.dropped_audio if self.session else 0, **self.metrics, **extra}

    def stop(self):
        self.core.close()
        self.running = False
        self.power = -120.0
        self.gate.reset()

    def handle(self, session, command):
        if session.dead.is_set():
            session.stopped.set()
            return
        if command["type"] == "attach":
            self.session = session
            session.outbox.put("status", self.status(error=self.core.error) if self.core.error else self.status())
            return
        if session is not self.session:
            return
        kind = command["type"]
        if kind in ("start", "tune"):
            settings = {**self.settings, **{key: value for key, value in command.items() if key != "type"}}
            if kind == "tune" and not self.running:
                self.settings = settings
                session.outbox.put("status", self.status())
                return
            if not self.running or settings["device"] != self.settings["device"]:
                self.stop()
                self.core.open(settings)
            else:
                self.core.tune(settings)
            self.settings = settings
            self.running = True
            self.power = -120.0
            self.gate.reset()
            self.last_samples = time.monotonic()
            # Flush USB/DSP settling data for ~43 ms after a retune. Browser
            # delivery is fenced by reset before any new-channel packets.
            self.settle = 4
            session.outbox.reset(self.status(reset=True))
        elif kind == "stop":
            self.stop()
            session.outbox.reset(self.status(reset=True))
        elif kind == "spectrum":
            self.spectrum = command["enabled"]
        elif kind == "squelch":
            self.settings["squelch"] = command["value"]

    def run(self):
        last_status = last_iq = 0.0
        self.settle = 0
        while not self.shutdown.is_set():
            if self.session and self.session.dead.is_set():
                self.stop()
                self.session.stopped.set()
                self.session = None
            try:
                item = self.commands.get(timeout=0 if self.running else 0.05)
            except queue.Empty:
                item = None
            if item:
                session, command = item
                if session is None:
                    if command.set_running_or_notify_cancel():
                        try:
                            command.set_result(self.core.devices())
                        except Exception as error:
                            command.set_exception(error)
                    continue
                try:
                    self.handle(session, command)
                except Exception as error:
                    self.stop()
                    session.outbox.reset(self.status(reset=True, error=str(error)))
                    session.outbox.put("error", {"type": "error", "message": str(error)})
                continue
            if not self.running or not self.session:
                continue
            session = self.session
            now = time.monotonic()
            want_iq = self.spectrum and now - last_iq >= 0.1
            try:
                result = self.core.read(want_iq)
                if result is None:
                    if time.monotonic() - self.last_samples > 3:
                        raise RuntimeError("Receiver has not delivered samples for 3 seconds. Check the USB connection and reconnect.")
                    continue
                if session.dead.is_set():
                    continue
                self.last_samples = time.monotonic()
                audio, self.power, iq, self.metrics = result
                if self.settle:
                    self.settle -= 1
                    continue
                audio = self.gate.process(audio, self.power, self.settings["squelch"])
                session.outbox.put("audio", struct.pack("<I", 1) + audio)
                if iq is not None:
                    session.outbox.put("iq", iq)
                    last_iq = now
                if now - last_status >= 0.1:
                    session.outbox.put("status", self.status())
                    last_status = now
            except Exception as error:
                self.stop()
                session.outbox.reset(self.status(reset=True, error=str(error)))
                session.outbox.put("error", {"type": "error", "message": str(error)})
        self.stop()
        if self.session:
            self.session.stopped.set()
        # A shutdown may race an attach command before it becomes self.session.
        # Resolve every queued waiter after the hardware is closed.
        while True:
            try:
                session, command = self.commands.get_nowait()
            except queue.Empty:
                break
            if session is not None:
                session.stopped.set()
            else:
                command.cancel()


class ProtocolError(Exception):
    pass


async def read_frame(reader):
    first, second = await reader.readexactly(2)
    opcode = first & 15
    if first & 0x70 or not first & 0x80 or not second & 0x80:
        raise ProtocolError("Only final, masked browser frames are accepted.")
    if opcode not in (1, 8, 9, 10):
        raise ProtocolError("Unsupported WebSocket frame.")
    size = second & 127
    if size == 126:
        size = struct.unpack("!H", await reader.readexactly(2))[0]
    elif size == 127:
        size = struct.unpack("!Q", await reader.readexactly(8))[0]
    if size > MAX_COMMAND or (opcode >= 8 and size > 125):
        raise ProtocolError("WebSocket message is too large.")
    mask = await reader.readexactly(4)
    payload = await reader.readexactly(size)
    return opcode, bytes(byte ^ mask[index & 3] for index, byte in enumerate(payload))


def encode_frame(opcode, payload):
    length = len(payload)
    prefix = bytes((0x80 | opcode, length)) if length < 126 else bytes((0x80 | opcode, 126)) + struct.pack("!H", length) if length <= 65535 else bytes((0x80 | opcode, 127)) + struct.pack("!Q", length)
    return prefix + payload


class Bridge:
    def __init__(self, core, port=8780, public=PUBLIC):
        self.core = core
        self.port = port
        self.public = Path(public).resolve()
        self.token = secrets.token_urlsafe(32)
        self.worker = ReceiverWorker(core)
        self.owner = None
        self.server = None

    def allowed_request(self, headers, require_origin=False):
        host = headers.get("host", "")
        hosts = {f"127.0.0.1:{self.port}", f"localhost:{self.port}"}
        if self.port == 80:
            hosts.update({"127.0.0.1", "localhost"})
        if host not in hosts:
            return False
        origin = headers.get("origin")
        canonical_host = host.removesuffix(":80") if self.port == 80 else host
        if origin is not None and origin != "http://" + canonical_host:
            return False
        if require_origin and origin is None:
            return False
        return headers.get("sec-fetch-site") not in {"cross-site", "same-site"}

    def diagnose(self, event, headers, path):
        # JSON escaping prevents log-line/control-character injection. Never
        # record a query, cookies, WebSocket key, or the process-session token.
        def safe(value):
            return str(value or "").split("?", 1)[0].split("#", 1)[0].replace(self.token, "[redacted]")[:256]
        record = {"event": event, "path": safe(path), "host": safe(headers.get("host")),
                  "origin": safe(headers.get("origin")), "secFetchSite": safe(headers.get("sec-fetch-site"))}
        print("Tuner bridge " + json.dumps(record, ensure_ascii=True, separators=(",", ":")), file=sys.stderr, flush=True)

    def headers(self):
        return {
            "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer",
            "Content-Security-Policy": f"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self' ws://127.0.0.1:{self.port} ws://localhost:{self.port} https://api.zippopotam.us; worker-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
            "Permissions-Policy": "camera=(), microphone=(), geolocation=(), usb=(self), serial=(self)",
        }

    async def respond(self, writer, code, body=b"", content_type="text/plain; charset=utf-8", head=False):
        names = {200: "OK", 400: "Bad Request", 403: "Forbidden", 404: "Not Found", 405: "Method Not Allowed", 409: "Conflict", 431: "Request Header Fields Too Large", 503: "Service Unavailable"}
        headers = {**self.headers(), "Content-Type": content_type, "Content-Length": str(len(body)), "Connection": "close"}
        writer.write((f"HTTP/1.1 {code} {names.get(code, 'Error')}\r\n" + "".join(f"{key}: {value}\r\n" for key, value in headers.items()) + "\r\n").encode("ascii"))
        if not head:
            writer.write(body)
        await asyncio.wait_for(writer.drain(), 2)

    async def handle(self, reader, writer):
        headers = {}
        target = ""
        try:
            try:
                raw = await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), 5)
            except (asyncio.LimitOverrunError, ValueError):
                self.diagnose("http_denied_headers", headers, target)
                await self.respond(writer, 431)
                return
            if len(raw) > 16384:
                self.diagnose("http_denied_headers", headers, target)
                await self.respond(writer, 431)
                return
            try:
                lines = raw.decode("ascii").split("\r\n")
                method, target, version = lines[0].split(" ")
                headers = {}
                for line in lines[1:]:
                    if not line:
                        continue
                    key, value = line.split(":", 1)
                    key = key.lower().strip()
                    if key in headers:
                        raise ValueError("Duplicate header")
                    headers[key] = value.strip()
                if version != "HTTP/1.1" or not target.startswith("/"):
                    raise ValueError("Invalid request line")
            except (ValueError, UnicodeError):
                self.diagnose("http_denied_request", headers, target)
                await self.respond(writer, 400)
                return
            if not self.allowed_request(headers):
                self.diagnose("http_denied_origin", headers, target)
                await self.respond(writer, 403, b"Only this local browser origin may access the receiver.")
                return
            if method not in ("GET", "HEAD"):
                self.diagnose("http_denied_method", headers, target)
                await self.respond(writer, 405)
                return
            parsed = urlsplit(target)
            if parsed.path == "/stream":
                if method != "GET":
                    self.diagnose("websocket_denied_method", headers, parsed.path)
                    await self.respond(writer, 405)
                else:
                    await self.websocket(reader, writer, headers, parsed.query)
                return
            if parsed.path == "/api/session":
                payload = {"token": self.token, "demo": self.core.demo, "version": VERSION, "audioRate": AUDIO_RATE,
                           "sampleRate": SAMPLE_RATE, "receiverBusy": self.owner is not None}
                await self.respond(writer, 200, json.dumps(payload).encode(), "application/json", method == "HEAD")
                return
            if parsed.path == "/api/devices":
                payload = await asyncio.wait_for(self.worker.devices(), 5)
                await self.respond(writer, 200, json.dumps(payload).encode(), "application/json", method == "HEAD")
                return
            relative = unquote(parsed.path).lstrip("/") or "index.html"
            try:
                path = (self.public / relative).resolve()
                path.relative_to(self.public)
                if not path.is_file():
                    raise FileNotFoundError()
                content = await asyncio.to_thread(path.read_bytes)
            except (ValueError, OSError):
                await self.respond(writer, 404)
                return
            mime = "text/javascript" if path.suffix in (".js", ".mjs") else mimetypes.guess_type(path.name)[0] or "application/octet-stream"
            await self.respond(writer, 200, content, mime, method == "HEAD")
        except (asyncio.TimeoutError, asyncio.IncompleteReadError, ConnectionError, OSError):
            pass
        finally:
            writer.close()
            try:
                await asyncio.wait_for(writer.wait_closed(), 1)
            except (asyncio.TimeoutError, ConnectionError, OSError):
                writer.transport.abort()

    async def websocket(self, reader, writer, headers, query):
        tokens = parse_qs(query).get("token", [])
        if not self.allowed_request(headers, require_origin=True) or len(tokens) != 1 or not hmac.compare_digest(tokens[0].encode("utf-8"), self.token.encode("ascii")):
            self.diagnose("websocket_denied_auth", headers, "/stream")
            await self.respond(writer, 403)
            return
        try:
            key = headers["sec-websocket-key"]
            if len(base64.b64decode(key, validate=True)) != 16 or headers.get("sec-websocket-version") != "13" or headers.get("upgrade", "").lower() != "websocket" or "upgrade" not in {part.strip().lower() for part in headers.get("connection", "").split(",")}:
                raise ValueError()
        except (KeyError, ValueError):
            self.diagnose("websocket_denied_handshake", headers, "/stream")
            await self.respond(writer, 400)
            return
        accept = base64.b64encode(hashlib.sha1((key + WS_GUID).encode()).digest()).decode()
        upgrade = f"HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: {accept}\r\n\r\n".encode()
        if self.owner is not None:
            self.diagnose("receiver_busy", headers, "/stream")
            # Browsers hide HTTP upgrade failures from JavaScript. Upgrade the
            # authenticated connection just long enough to deliver the reason;
            # this branch never acquires or releases the existing owner's lease.
            message = {"type": "error", "code": "receiver_busy", "message": "The receiver is in use in another browser tab. Stop it there, then press Start here."}
            writer.write(upgrade)
            writer.write(encode_frame(1, json.dumps(message, separators=(",", ":")).encode()))
            writer.write(encode_frame(8, struct.pack("!H", 1013) + b"Receiver in use"))
            await asyncio.wait_for(writer.drain(), 2)
            return
        session = Session(asyncio.get_running_loop())
        self.owner = session
        sender = None
        receiver = None
        attached = False
        try:
            self.worker.submit(session, {"type": "attach"})
            attached = True
            writer.write(upgrade)
            await asyncio.wait_for(writer.drain(), 2)
            transport_socket = writer.get_extra_info("socket")
            transport_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            transport_socket.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 16_384)
            writer.transport.set_write_buffer_limits(high=16_384, low=4096)
            sender = asyncio.create_task(self.send_packets(session, writer))
            receiver = asyncio.create_task(self.receive_commands(session, reader))
            done, pending = await asyncio.wait({sender, receiver}, return_when=asyncio.FIRST_COMPLETED)
            for task in pending:
                task.cancel()
            await asyncio.gather(*done, *pending, return_exceptions=True)
        finally:
            session.dead.set()
            session.outbox.close()
            # Abort queued socket bytes immediately. A driver that is slow to
            # close must not leave the browser waiting on a half-open stream.
            writer.transport.abort()
            tasks = [task for task in (sender, receiver) if task is not None]
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            if not attached:
                session.stopped.set()
            # Ownership is retained until the worker really closes the USB
            # handle, including a disconnect racing queued start/tune commands.
            # Poll asynchronously: Event.wait in an executor would leave an
            # uncancellable thread keeping asyncio.run alive on driver failure.
            while not session.stopped.is_set():
                await asyncio.sleep(0.025)
            if self.owner is session:
                self.owner = None

    async def receive_commands(self, session, reader):
        while True:
            try:
                opcode, payload = await read_frame(reader)
                if opcode == 8:
                    return
                if opcode == 9:
                    session.outbox.put("pong", payload)
                    continue
                if opcode == 10:
                    continue
                try:
                    command = validate_command(json.loads(payload.decode("utf-8")))
                    self.worker.submit(session, command)
                except (ValueError, UnicodeError, TypeError) as error:
                    session.outbox.put("error", {"type": "error", "message": str(error)})
            except (ProtocolError, asyncio.IncompleteReadError, ConnectionError):
                return

    async def send_packets(self, session, writer):
        while True:
            item = await session.outbox.get()
            if item is None:
                return
            kind, payload = item
            if kind == "pong":
                opcode = 10
            elif kind in ("audio", "iq"):
                opcode = 2
            else:
                opcode = 1
                payload = json.dumps(payload, allow_nan=False, separators=(",", ":")).encode()
            writer.write(encode_frame(opcode, payload))
            # A stalled tab is disconnected instead of accumulating live delay.
            await asyncio.wait_for(writer.drain(), 0.5)

    async def start(self):
        self.server = await asyncio.start_server(self.handle, "127.0.0.1", self.port, limit=16384)
        self.port = self.server.sockets[0].getsockname()[1]
        return self.server

    async def close(self):
        if self.owner:
            self.owner.dead.set()
            self.owner.outbox.close()
        self.worker.shutdown.set()
        await asyncio.to_thread(self.worker.thread.join, 2)
        if self.server:
            self.server.close()
            await self.server.wait_closed()


async def run(args):
    core = DemoCore() if args.demo else NativeCore(args.core)
    bridge = Bridge(core, args.port)
    try:
        await bridge.start()
        mode = "DEMONSTRATION SIGNAL — no hardware" if args.demo else "local RTL-SDR receiver"
        print(f"Tuner {VERSION} browser bridge ({mode})\nOpen http://127.0.0.1:{bridge.port}\nPress Ctrl+C to stop.", flush=True)
        if core.error:
            print(core.error, flush=True)
        if args.open:
            await asyncio.to_thread(webbrowser.open, f"http://127.0.0.1:{bridge.port}")
        await bridge.server.serve_forever()
    finally:
        await bridge.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8780)
    parser.add_argument("--core", type=Path, help="Path to the receiver shared library")
    parser.add_argument("--demo", action="store_true", help="Explicit synthetic test signal; no USB receiver is opened")
    parser.add_argument("--open", action="store_true", help="Open the local receiver in your default browser")
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("port must be 1–65535")
    try:
        asyncio.run(run(args))
    except KeyboardInterrupt:
        pass
    except OSError as error:
        parser.exit(1, f"Could not start local receiver: {error}\n")


if __name__ == "__main__":
    main()
